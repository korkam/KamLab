
function ctemp = kelvin_to_celsius(ktemp)
    ctemp = ktemp - 273.15;