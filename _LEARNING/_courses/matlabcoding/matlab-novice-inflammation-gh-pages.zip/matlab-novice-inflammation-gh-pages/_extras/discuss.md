---
layout: page
title: Discussion
---

## Motivation

Here is a great article discussing the need for better practices in
scientific computing:

http://www.americanscientist.org/issues/num2/wheres-the-real-bottleneck-in-scientific-computing/1
