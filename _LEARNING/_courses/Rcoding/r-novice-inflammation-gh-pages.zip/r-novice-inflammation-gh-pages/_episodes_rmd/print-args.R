args <- commandArgs()
cat(args, sep = "\n")
