args <- commandArgs(trailingOnly = TRUE)
cat(args, sep = "\n")
