---
layout: page
title: Discussion
permalink: /discuss/
---
Please see [our other R lesson][r-gap] for a different presentation of these concepts.

[r-gap]: https://swcarpentry.github.io/r-novice-gapminder/
