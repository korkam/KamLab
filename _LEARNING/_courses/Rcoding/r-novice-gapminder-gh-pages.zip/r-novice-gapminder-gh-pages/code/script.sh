#!/usr/bin/env bash
#  script.sh: A shell script
echo "Hello world!"
