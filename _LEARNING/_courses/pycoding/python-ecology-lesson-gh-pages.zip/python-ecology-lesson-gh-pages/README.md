## Data Carpentry Python Lessons with Ecological Data

This repository contains the Data Carpentry Python material based on ecological
data. Please see our [contribution guidelines](CONTRIBUTING.md) for information
on how to contribute updates, bug fixes, or other corrections.

### Maintainers

- April Wright ([@wrightaprilm](https://github.com/wrightaprilm))
- John Gosset ([@qjcg](https://github.com/qjcg))
- Mateusz Kuzak ([@mkuzak](https://github.com/mkuzak))
