---
layout: break
title: "Lunch"
teaching: 0
exercises: 0
break: 60
---

Talk to people about why they are taking this course.
How do their reasons compare to yours?
