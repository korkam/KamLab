---
title: "Cognitive Load"
teaching: 20
exercises: 20
questions:
- "How does inquiry-based learning perform compared to guided learning?"
- "What is cognitive load theory?"
- "What is the split-attention effect, and how should it affect the design of teaching materials?"
objectives:
- "Explain the basis and implications of cognitive load theory and critique it."
- "Construct faded examples for use as classroom exercises and explain the problem-solving strategies those examples illustrate."
keypoints:
- "Self-directed (inquiry-based) learning is less effective than guided instruction."
- "Cognitive load theory predicts that focusing on one aspect at a time improves learning."
- "Use faded examples to focus attention when learning."
---

In our final topic in educational psychology, we'll be learning more about human memory:
specifically how to remove unnecessary "load" in order to facilitate learning.

## Battling Theories

In 2006,
Kirschner, Sweller, and Clark published a paper titled
"[Why Minimal Guidance During Instruction Does Not Work: An Analysis of the Failure of Constructivist, Discovery, Problem-Based, Experiential, and Inquiry-Based Teaching][kirschner-paper]".
In the abstract, they say:

> Although unguided or minimally guided instructional approaches
> are very popular and intuitively appealing...these approaches
> ignore both the structures that constitute human cognitive architecture
> and evidence from empirical studies over the past half-century
> that consistently indicate that minimally guided instruction is less effective and less efficient than
> instructional approaches that place a strong emphasis on guidance of the student learning process.
> The advantage of guidance begins to recede only when learners have
> sufficiently high prior knowledge to provide "internal" guidance.
{: .quotation}

The paper set off a minor academic firestorm,
because beneath the jargon the authors were claiming that
[inquiry-based learning][wikipedia-inquiry]---allowing
learners to ask their own questions,
set their own goals,
and find their own path through a subject---doesn't actually work very well.
Kirschner et al's argument was that it requires learners to simultaneously
master a domain's factual content
and its search and problem-solving strategies.
Fostering creativity and independence is intuitively appealing,
but that doesn't mean it works.

One of the paper's authors (Sweller) proposed an alternative
based on the theory of *[cognitive load][wikipedia-cognitive-load]*.
It posits that people have to deal with three things when they're learning:

*   *Intrinsic* load is what they have to keep in mind in order to carry out a learning task.
*   *Germane* load is the (desirable) mental effort required to create linkages between new information and old
    (which is one of the things that distinguishes learning from memorization).
*   *Extraneous* load is everything else that distracts or gets in the way.

Cognitive load theory's proponents claim that eliminating extraneous cognitive load accelerates learning.
Unsurprisingly,
it too has [been criticized][cognitive-load-crit],
most particularly for being unfalsifiable.
Critics of cognitive load theory say that
since there's no way to tell in advance of an experiment whether something is germane or not,
any result can be justified after the fact
by labelling things that hurt performance as "extraneous"
and things that don't "germane".

However,
some predictions *can* be made.
One example is work by Mayer and colleagues on
the *[split-attention effect][wikipedia-split-attention]*.
Linguistic and visual input are processed by different parts of the human brain,
and linguistic and visual memories are stored separately as well.
This means that correlating different linguistic, auditory, and visual streams of information takes cognitive effort:
when someone reads one thing while hearing something else spoken aloud,
their brain can't help but check that it's getting the same information on both channels.
Discrepencies between these channels increase cognitive load and decrease learning.
Learning is therefore more effective when information that is being presented simultaneously
in two different channels is redundant, rather than different. 
For our workshops, this means the instructor should say out loud commands as they type them on the screen
during live coding.

## Faded Examples

According to cognitive load theory,
searching for a solution strategy is an extra burden
on top of applying that strategy.
We can therefore accelerate learning
by giving learners worked examples that show them a problem and a detailed step-by-step solution,
followed by a series of *faded examples*.
The first of these presents a nearly-complete use of the same problem-solving strategy just demonstrated
with a small number of blanks for the learner to fill in.
The next problem is also of the same type,
but has more blanks,
and so on until the learner is asked to solve the entire problem.

Faded examples work because they introduce the problem-solving strategy piece by piece.
At each step,
learners have one new problem to tackle.
This is less intimidating than a blank screen or a blank sheet of paper.
It also encourages learners to think about the similarities and differences between various approaches,
which helps create the linkages in the mental model that instructors want them to form.

For example,
someone teaching Python might start by explaining this:

~~~
# total_length(["red", "green", "blue"]) => 12
def total_length(words):
    total = 0
    for word in words:
        total += len(word)
    return total
~~~
{: .source}

then ask learners to fill in the blanks in:

~~~
# word_lengths(["red", "green", "blue"]) => [3, 5, 4]
def word_lengths(words):
    lengths = ____
    for word in words:
        lengths ____
    return lengths
~~~
{: .source}

The next problem might be:

~~~
# concatenate_all(["red", "green", "blue"]) => "redgreenblue"
def concatenate_all(words):
    result = ____
    for ____ in ____:
        ____
    return result
~~~~
{: .source}

and learners would finally be asked to tackle:

~~~
# acronymize(["red", "green", "blue"]) => "RGB"
def acronymize(words):
    ____
~~~
{: .source}

The key to constructing a good faded example is to think about the problem-solving strategy
or solution pattern that it is meant to teach.
For example,
the series of problems above illustrate the *accumulator pattern*,
in which the results of processing items from a collection
are repeatedly added to a single variable in some way
to create the final result.

> ## Create a Faded Example from a Lesson
>
> The following exercise should be done in groups of 2-3.
>
> 1.  Pick a block of code from an existing Software or Data Carpentry lesson,
>     or from another lesson you have taught recently.
> 2.  Replace 2-3 pieces of the code with a blank.
> 3.  Write a question to test the student's ability to correctly fill in that blank.
> 4.  Take 10 minutes for this exercise.
> 5.  Paste your faded example in the Etherpad.
{: .challenge}

## Parsons Problems

Another kind of exercise designed to reduce cognitive load is a *Parsons Problem*,
in which learners are presented with the jumbled parts of a solution
and asked to put them in order.
When learning a language,
for example,
students could be asked to order a set of words
to create a grammatically correct response to a question.
Similarly,
our learners can be given the lines of code needed to solve a problem
and asked to arrange them.
Learners can then be told that they have all the lines they need save one,
and so on.

Here is a really nice online Parsons Problem interactive tool. [Try it out!](http://runestoneinteractive.org/LearningAtScale/parsons.html)

> ## Parsons Problems
>
> Challenge option 1: Jumbled with an unnecesasary line
> 1. Write 5 or 6 lines of code that does something useful,
> 2. jumble them,
> 3. then add one more line that looks plausible but isn't needed to solve the problem.
> 4. How well can your partner tell which line is unnecessary?
>
>
> Challenge option 2: Simply jumbled
> 1. Pick a block of code from an existing Software or Data Carpentry lesson, or from another lesson you have taught recently.
> 2. Jumble the code
> 3. Paste your jumbled code block into the etherpad
> 4. Determine the correct order of your partner's else's code block 
>
> This challenge should take about 10 minutes. 
> {: .challenge}

[cognitive-load-crit]: https://edtechdev.wordpress.com/2009/11/16/cognitive-load-theory-failure/
[kirschner-paper]: http://www.cogtech.usc.edu/publications/kirschner_Sweller_Clark.pdf
[memory-test]: http://cat.xula.edu/thinker/memory/working/serial
[wikipedia-cognitive-load]: https://en.wikipedia.org/wiki/Cognitive_load
[wikipedia-inquiry]: https://en.wikipedia.org/wiki/Inquiry-based_learning
[wikipedia-split-attention]: https://en.wikipedia.org/wiki/Split_attention_effect
