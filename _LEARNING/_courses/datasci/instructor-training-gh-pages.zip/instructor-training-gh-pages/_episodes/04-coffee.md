---
layout: break
title: "Morning Coffee"
teaching: 0
exercises: 0
break: 15
---

Find someone who shares something surprising in common with you (e.g. your pet has the same name,
or you both brush your teeth in the shower). Put your "surprise" similarity into the Etherpad when
you come back from break and vote on the most surprising.

We really want you to get to know your fellow learners and become comfortable interacting. There
will be several interactive activities in the next two days. Let's all start bonding now.
