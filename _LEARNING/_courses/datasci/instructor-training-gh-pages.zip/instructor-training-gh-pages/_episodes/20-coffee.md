---
layout: break
title: "Afternoon Coffee"
teaching: 0
exercises: 0
break: 15
---

How practical do you think it would be to use the techniques you've learned in this workshop
in regular teaching?
In particular,
do you think you would have enough time to prepare and teach lessons
the ways you have been shown?
