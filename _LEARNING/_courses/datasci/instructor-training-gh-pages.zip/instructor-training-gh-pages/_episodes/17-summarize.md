---
title: "Morning Wrap-Up"
teaching: 0
exercises: 5
questions:
- "What have we learned?"
objectives:
- "Be proficient at using minute cards for actionable feedback."
keypoints:
- "Use sticky notes for collecting end-of-class feedback."
---

> ## Minute Cards Revisited
>
> Use your sticky notes to write minute cards
> as discussed [yesterday]({{ page.root }}/06-summarize/).
{: .challenge}
