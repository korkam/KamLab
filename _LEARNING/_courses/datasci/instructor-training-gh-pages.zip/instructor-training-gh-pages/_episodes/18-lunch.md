---
layout: break
title: "Lunch"
teaching: 0
exercises: 0
break: 60
---

If you have taken part in a Software or Data Carpentry workshop,
how do your experiences compare to those of other people?
If you haven't,
what questions do you have that they might be able to answer?
