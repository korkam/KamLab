---
layout: break
title: "Morning Coffee"
teaching: 0
exercises: 0
break: 15
---

How does live coding compare to other kinds of demonstration-based teaching
like lab lessons?
