---
layout: break
title: "Afternoon Coffee"
teaching: 0
exercises: 0
break: 15
---

Do concept maps feel useful to you?
Are there other ways of drawing knowledge that appeal to you more?
