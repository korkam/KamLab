git-novice
==========

An introduction to version control for novices using Git.
Please see <https://swcarpentry.github.io/git-novice/> for a rendered version of this material,
[the lesson template documentation][lesson-example]
for instructions on formatting, building, and submitting material,
or run `make` in this directory for a list of helpful commands.

Maintainers:

* [Ivan Gonzalez][gonzalez_ivan]
* [Daisie Huang][huang_daisie]

[gonzalez_ivan]: http://software-carpentry.org/team/#gonzalez_ivan
[huang_daisie]: http://software-carpentry.org/team/#huang_daisie
[lesson-example]: https://swcarpentry.github.io/lesson-example
