# Case-Studies-Kramer-Eden

This material is based upon work supported in part by the National Science Foundation under Grant Number #1451384. Any opinions, findings, and conclusions or recommendations expressed in this material are those of the author(s) and do not necessarily reflect the views of the National Science Foundation.

- This repository now includes an <a href="https://github.com/Mark-Kramer/Case-Studies-Kramer-Eden/blob/master/Erratum.pdf">Erratum.pdf</a>.  I will post corrections here.  Please report typos/errors on github as Issues, or email Mark.
