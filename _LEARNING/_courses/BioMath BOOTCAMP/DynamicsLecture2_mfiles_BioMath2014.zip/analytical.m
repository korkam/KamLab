A = [0 1 ; -1 -0.5];
[V, D] = eig(A);


r0 = [1 ; 1];
rho0 = inv(V)*r0;

t = 10;

rho10_first_component  = rho0(1) * exp(D(1,1)*t);
rho10_second_component = rho0(2) * exp(D(2,2)*t);


rho10 = [rho10_first_component ; rho10_second_component];

r10 = V*rho10;

