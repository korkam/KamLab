% [] = side_by_side(A, {'bot' -3}, {'top', 3}, {'dx, 0.4}, ...
%         {'headscale', 3}, {'dt', 0.1}, {'npoints', 20}, ...
%         {'nsteps', 1000}, {'newevery', 1000}, {'show_evecs', 0}, ...
%         {'show_diag_dyn', 0}, {'replace_outputs', 1)
%
% Plots 2d linear dynamics given by xdot = A x in figure 1, and the
% diagonalized version in figure 2.
%
% OPTIONAL PARAMETERS:
%
%  'bot'  The lower limit of points to show as arrow starts
%
%  'top'  The upper limit of points to show as arrow starts
%
%  'dx'   The spacing between arrow bases
%
%  'headcale'  The factor by which to scale arrowhead lengths
%
%  'dt'   Timestep for Euler integration
%
%  'npoints'  Number of particles to show
%
%  'nsteps'  Total number of timesteps over which to do the integration
%
%  'newevery'  Every this many timesteps, delete a particle and
%              add a new one at a random position.
%
%  'show_evecs'   If 1, put lines up to show eigenvector directions
%
%  'show_diag_dyn'  If 1, then also show everything in diagonalized basis
%                   in figure 2
%
%  'replace_outpts' If 1, replace points that go out of bounds with a new
%                   point at a random position
%
%
% EXAMPLE CALLS:
%
%  A = [-1 1 ; -1 1.5];
%  side_by_side(A, 'newevery', 1e6, 'dt', 0.01, 'npoints', 20, 'show_diag_dyn', 1, 'show_evecs', 1, 'replace_outpts', 1)
%



function [] = side_by_side(A, varargin)

pairs = { ...
    'bot'            -3    ; ...
    'top'             3    ; ...
    'dx'              0.4  ; ...
    'headscale'       3    ; ...
    'dt'              0.1  ; ...
    'npoints'         20   ; ...
    'nsteps'          1000 ; ...
    'newevery'        1000 ; ...
    'show_evecs'      1    ; ...
    'show_diag_dyn'   1    ; ...
    'replace_outpts'  1    ; ...
}; parseargs(varargin, pairs);

[V, D] = eig(A); V = -V; % V(:,1) = V(:,1);

figure(2); clf;
figure(1); clf;

if show_evecs,  vlines = V;
else            vlines = [];
end;
make_quiver_plot(A, bot, top, dx, headscale, vlines);
title('Original space');


if show_diag_dyn
    figure(2); clf;
    if show_evecs, vlines = [0 1 ; 1 0];
    else           vlines = [];
    end;
    make_quiver_plot(D, bot, top, dx, headscale, vlines);
    title('Eigenvector space');
end;


r = rand(2,npoints)*(top-bot)+bot;
colors = rand(npoints,3);

figure(1); 
hr = draw_initial_points(r, colors);
ax1 = gca;

if show_diag_dyn
    iV = inv(V);
    d = iV*r;    
    figure(2);
    hd = draw_initial_points(d, colors);
    ax2 = gca;
end;

ctr = 0;
for j=1:nsteps,
    r = r + dt*A*r;
    for p=1:npoints,
        set(hr(p), 'XData', r(1,p), 'YData', r(2,p));
    end;
    set(ax1, 'XLim', [bot-1 top+1], 'YLim', [bot-1 top+1]);

    if show_diag_dyn
        d = iV*r;
        for p=1:npoints,
            set(hd(p), 'XData', d(1,p), 'YData', d(2,p));
        end;
        set(ax2, 'XLim', [bot-1 top+1], ...
            'YLim', [bot-1 top+1]);
    end;
    drawnow;
        
    if rem(j, newevery)==0,
        ctr = rem(ctr, npoints)+1 ;
        r(:,ctr) = rand(2,1)*(top-bot)+bot;
        if show_diag_dyn
            d = iV*r;
        end;
    end;
    if replace_outpts,
        j = find(r(1,:) < bot-1 | r(1,:) > top+1 | r(2,:) < bot-1 | r(2,:) > top+1);
        r(:,j) = rand(2, length(j))*(top-bot)+bot;
        if show_diag_dyn
            d = iV*r;
        end;
    end;
end;




%  -----------

% [] = make_quiver_plot(A, bot, top, dx, headscale, V)
%
% Uses twoDquiver.m to make a quiver plot for xdot=Ax. In addition, if V is
% not empty, adds red lines along the directions pointed to by the columns
% of V. 
%

function [] = make_quiver_plot(A, bot, top, dx, headscale, V)

twoDquiver(A, bot, top, dx, headscale);
axis equal;
set(gca, 'FontSize', 16);
if ~isempty(V),
    escale = top-bot;
    line(escale*[-V(1,:) ; V(1,:)],...
        escale*[-V(2,:) ; V(2,:)], 'Color', 'r'); 
end;

axis equal; ax1 = gca;
set(ax1, 'XLimMode', 'manual', 'YLimMode', 'manual');
set(ax1, 'XLim', [bot-1 top+1], 'YLim', [bot-1 top+1]);


% ---------

% [hr] = draw_initial_points(r, colors)
%
% For each column i of r, adds a point to the plot, at position 
% (r(1,i), r(2,i)), with color given by colors(i,:). Returns a vector of
% graphics handles with a length equal to the number of points.
%
% PARAMETERS
%
%  r must be a 2-by-npoints matrix
%
%  colors must be a npoints-by-3 matrix, specifying the [r,g,b] for each
%  point. Each of r, g, and b for each point must be in [0,1].
%
% RETURNS
%
%  hr a vector npoints long of graphics handles, one per point.
%

function [hr] = draw_initial_points(r, colors)



hr = zeros(1, size(r,2));
for p=1:size(r,2),
    hr(p) = line(r(1,p), r(2,p), 'Marker', '.', ...
        'MarkerSize', 26, 'Color', colors(p,:));
end;
