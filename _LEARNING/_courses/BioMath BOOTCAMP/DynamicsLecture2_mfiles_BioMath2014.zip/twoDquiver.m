function [hquiver] = twoDquiver(A, bot, top, dx, headscale)
% twoDquiver(A, bot, top, dx)
%
% Takes a 2-by-2 matrix A, and assuming dynamics such that dx/dt = A x, plots out
% the quiver plot for the corresponding dynamics. That is, at each of a
% field of points in the 2-d space, plots an arrow that points in the
% direction of dx/dt, i.e., the direction in which the dynamical flow will
% go.
%
% The field of points is goes from bot:dx:top in each of the two dumensions
%
% PARAMETERS:
%
%   A    A 2-by-2 matrix
%
%   bot  the smallest y-axis value and x-axis value to plot an arrow for
%
%   top  the largest y-axis value and x-axis value to plot an arrow for
%
%   dx   The x- and y- distance between points that are plotted.
%
%   headcale   By default 1,  scales the arrowhead size
%
%  EXAMPLE:
%
%  >> A = [cos(pi/2) sin(pi/2) ; -sin(pi/2) cos(pi/2)];
%  >> twoDquiver(A, -2, 2, 0.3);
%

if nargin < 5,
    headscale = 1;
end;

x = bot:dx:top;
y = bot:dx:top;

xs    = zeros(1, numel(x)*numel(y));
ys    = zeros(1, numel(x)*numel(y));
xdots = zeros(1, numel(x)*numel(y));
ydots = zeros(1, numel(x)*numel(y));


k=0;
for i=1:numel(x),
   for j=1:numel(y),
      deriv = A*[x(i); y(j)];

      k = k+1;
      xs(k)    = x(i);
      ys(k)    = y(j);
      xdots(k) = deriv(1);
      ydots(k) = deriv(2);
   end;
end;


hquiver = quiver(xs, ys, xdots, ydots, headscale);

% hold on;
% hdots = plot(xs, ys, 'b.');
% hold off;

