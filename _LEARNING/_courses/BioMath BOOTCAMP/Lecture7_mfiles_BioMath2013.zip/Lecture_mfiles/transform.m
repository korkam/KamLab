% [] = transform(M)    Show the transformation that a 2-by-2 matrix does
%
% M should be a 2-by-2 matrix

function [] = transform(M)

xpos = -5:5;
ypos = -5:5;

clf;
for i=1:numel(xpos),
	for j=1:numel(ypos),
		vector_x = [xpos(i) ; ypos(j)];
		new_vector_x = M * vector_x;
		
		plot([vector_x(1) new_vector_x(1)], ...
			[vector_x(2) new_vector_x(2)]);
		hold on;
		plot(new_vector_x(1), new_vector_x(2), 'r.');
		plot(vector_x(1), vector_x(2), '.', 'Color', [0 0.5 0]);
	end;
end;

axis square;
xlim([-12 12]);
ylim([-12 12]);

	
