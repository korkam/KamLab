load example_data
clf;
set(plot(X(1,:), X(2,:), 'b.'), 'MarkerSize', 10);

N = size(X,2);

Y = X - mean(X,2)*ones(1,size(X,2));
set(gca, 'FontSize', 16);

hold on;
plot(Y(1,:), Y(2,:), 'g.', 'MarkerSize', 10);


C = (Y*Y')/N;

[V, D] = eig(C);

alpha = 5;
plot(alpha*[0 V(1,1)], alpha*[0, V(2,1)], 'k-');
plot(alpha*[0 V(1,2)], alpha*[0, V(2,2)], 'k-');

axis equal;


Z = inv(V)*Y;

plot(Z(1,:), Z(2,:), 'r.', 'MarkerSize', 10);
