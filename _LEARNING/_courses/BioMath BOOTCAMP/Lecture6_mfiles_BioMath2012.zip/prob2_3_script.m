theta = 90; 
theta_in_radians = theta*pi/180; 
% The "..." means "continue on next line
B = [cos(theta_in_radians) sin(theta_in_radians) ; ...
	-sin(theta_in_radians) cos(theta_in_radians)];
Mprime = B*M*inv(B);

visualize_mapping(Mprime);
