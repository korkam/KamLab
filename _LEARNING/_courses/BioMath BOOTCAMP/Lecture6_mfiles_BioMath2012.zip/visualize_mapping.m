% [] = visualize_mapping(M)
%
% Plots a blue field of dots, then puts each one through the matrix M
% and plots a line to the corresponding new dot, and a red dot at the end
% of the line.
%
% INPUTS:
% -------
%
%   M    a 2x2 matrix
%

function [] = visualize_mapping(M)

if size(M,1)~=2 || size(M,2)~=2
	error('Sorry, can only work with %dx%d matrices', 2, 2);
end;

horizontal_pos = -10:2:10;
vertical_pos   = -10:2:10;

Orig = zeros(2,numel(horizontal_pos)*numel(vertical_pos));
New  = zeros(2,numel(horizontal_pos)*numel(vertical_pos));

% Make all the original points:
counter = 1;
for i=1:numel(vertical_pos),
	for j=1:numel(horizontal_pos),
		Orig(:,counter) = [horizontal_pos(j) ; vertical_pos(i)];
		counter = counter+1;
	end;
end;

% Now find all the new positions, after going through the matrix M
% for i=1:size(Orig,2)
% 	New(:,i) = M*Orig(i,:);
% end;
% faster way to write it:
New = M*Orig;

% We're choosing to tell Matlab which figure number to use:
figure(1);
clf;
% Matrix X will hold a column for each of the points; and each column
% will have as first element the old horiz coord and as second element 
% the new horiz coord
X = [Orig(1,:) ; New(1,:)];
Y = [Orig(2,:) ; New(2,:)];

% When given two matrices of equal size, plot puts up one separate line per
% column 
% We can specify the color if we want
plot(X, Y, 'Color', [0 0.5 0]);
% We want to add to the plot so let's call "hold on"
hold on;
% The '.' specifies "don't put lines down, just put a dot at each of the
% specified points"
plot(Orig(1,:), Orig(2,:), 'b.');
plot(New(1,:), New(2,:), 'r.');

% this command forces the same range on x and y axes:
axis equal
