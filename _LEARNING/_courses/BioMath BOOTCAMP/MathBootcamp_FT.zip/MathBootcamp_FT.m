ampl=10;
L=6;

x=0:.1:24;
y=ampl*sin(2*pi/L*x);

%%

x=1:1:1000; %box size 1000
L=1000;

s=x-mean(x); % this makes a linear sawtooth;
f=0;
for n=1:100
g1=sin(2*pi/L*n*x); %first sin wave
b1(n)=2/L*sum(g1.*s); %coef for first sin

f=f+g1*b1(n);

plot(x,s,'linewidth',3); %plot of the square wave
hold on
plot(x,f,'linewidth',3);
hold off;
pause(.1)
end



%% calculate fourier transforms

ampl=10;
L=6; %period of cos wave

x=0:.1:24;
N=length(x); % 241
y=ampl*cos(2*pi/L*x+pi/2); % this is a cos wave with a phase shift


%plot(x,y)
Fy=fft(y);
y2=ifft(Fy); % this can be used to recreate y
%plot(abs(Fy),'linewidth',4);
%first half :(0:N/2-1)
%box size : 1/N
%sampling rate : (1/.1);
freq=(0:N/2-1)*1/N*(1/.1); % find the corresponding freq for first half

Fy_firsthalf=Fy(1:N/2); % take first half of fft
plot(x,y,'linewidth',4);
figure;
plot(freq,real(Fy_firsthalf),'linewidth',4)
hold on
plot(freq,imag(Fy_firsthalf),'linewidth',4)
hold off


%% power spectrum

Fy_power=Fy_firsthalf;
Fy_power(2:end)=2*Fy_power(2:end); % amplify all freq except 0;

Fy_power=abs(Fy_power).^2;

plot(freq,Fy_power,'linewidth',4);










