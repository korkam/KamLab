check_size = 3;
N_checks   = 40;


%  ----  MAKING A SINGLE SQUARE ----
% pedestrian method #1:

pos_square = [];
n=1;
while n<=check_size;
	pos_square = [pos_square 1];
	n = n+1;
end;
single_row = pos_square; 

for n=1:check_size-1,
	pos_square = [pos_square ; single_row];
end;
% Above code is equivalent to:
% n=1;
% while n<check_size
%   
%    n=n+1;
% end;

% single-line version
pos_square = ones(check_size, check_size);   % ones(M,N) makes a mtrix M rows and N columns where each element is 1
neg_square = -ones(check_size, check_size);
neg_square = ~ones(check_size, check_size);
neg_square = zeros(check_size, check_size);  % zeros(M,N) makes a mtrix M rows and N columns where each element is 0



% size(M) returns two things, the rows and the columns; so we could use
% size(pos_square) to check that we got it right.


% ------ MAKING THE CKECKERBOARD ----

final_matrix = zeros(check_size*N_checks, check_size*N_checks);

% first_column  = 9;
% first_row     = 6;

% ... means line of code continues on the next line
% final_matrix(first_row:first_row+check_size-1, first_column:first_column+check_size-1) = ...
% 	pos_square;

% Loop over all rows and columns
for row=1:N_checks,
	for column=1:N_checks,
		full_matrix_row = (row-1)*check_size + 1;
		full_matrix_col = (column-1)*check_size + 1;
		
		% if (row+col)/2 == round((row+col)/2)
		if rem(row+column,2) == 0,
			final_matrix(full_matrix_row:full_matrix_row+check_size-1, ...
				full_matrix_col:full_matrix_col+check_size-1) = pos_square;
		end;
	end;
end;


imagesc(final_matrix); colormap gray;



