function [E] = make_histo(n, k)
% [E] = make_histo(n, k)
%
%  rolls an even n-sided die k times, plots a histogram of the distribution
%  of outcomes, and returns the mean squared difference between the
%  fraction of outcomes and the expected 1/n fraction

outcomes = 1:n;

r = ndice(n, k);
binheights = hist(r, n);
% binheights is a vector, where each element corresponds to a toll outcome
% and the value of the element is the number of rolls that came out as that
% outcome

frac = binheights/k;  % k is number of rolls
% frac is a vector with the fraction of rolls that came out to the
% corresponding outcome

bar(1:n, frac);
ylabel('fraction of rolls');
xlabel('roll outcome');

set(gca, 'FontSize', 20);

expected_frac = 1/n;

E = mean((expected_frac - frac).^2);

