function [] = animated_wave()

t = 0:0.01:10;

h = plot(t, sin(t));

mytime = 0;
while true,
    mytime = mytime + 0.1;
    amplitude = cos(mytime);
    ydata = sin(t)*amplitude;
    set(h, 'YData', ydata);
    ylim([-1.1 1.1]);
    drawnow;  % execute all pending graphics commands
end;


while 1,
    ydata = get(h, 'YData');
    ydata = [ydata(end-1:end) ydata(1:end-2)];
    set(h, 'YData', ydata);
    drawnow;  % execute all pending graphics commands
    % h = plot(t, ydata);
    % drawnow;
end;

