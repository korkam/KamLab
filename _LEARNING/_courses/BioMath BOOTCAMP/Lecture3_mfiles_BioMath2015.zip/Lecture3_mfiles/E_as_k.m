function [] = E_as_k(n, ks)
% [] = E_as_k(ks)
%
% Given n (sides of an even die) and ks (a vector of k rolls), plots the
% mean squared error as a function of k
%
load filename10

E_vector = zeros(size(ks));

for i=1:length(ks)
    E_vector(i) = make_histo(n, ks(i));
end;

clf; 
semilogy(ks, E_vector, 'b-o');
set(gca, 'FontSize', 20);
