% [counts] = count_all_letters(str)
%
% Counts how many there are of each letter in a string and puts up a bar
% plot to show them

function [counts] = count_all_letters(str)


all_the_letters = unique(str);                       % unique set of all letters in str
counts          = zeros(1, length(all_the_letters));  % each element will be the count for each letter

for whatever_name_i_want=1:length(all_the_letters)
	my_letter = all_the_letters(whatever_name_i_want);
	counts(whatever_name_i_want) = count_single_letter(str, my_letter);
end;


bar(counts);  % makes a bar plot

for i=1:length(all_the_letters),
	% text puts up a string on the graph that you are making
	text(i, counts(i)+10, all_the_letters(i), 'HorizontalAlignment', 'center');
end;

