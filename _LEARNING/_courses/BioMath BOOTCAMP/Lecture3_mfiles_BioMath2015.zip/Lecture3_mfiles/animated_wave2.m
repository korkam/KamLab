function [] = animated_wave2(period, nperiods)

% We're going to do our plotting on figure 1:
figure(1);
clf;   % clear figure

% maximum time we're going to look at
maxt = period*nperiods;
% a vector that defines time
t = 0:0.01:maxt;
% make a sine wave with the desired period:
y = sin(t*2*pi/period);
h = plot(t, y, 'Color', [0 0.3 0]);  % Color here is defined as [r, g, b]
% Make the straight lines that join the dots that define the plot be
% dashes:
set(h, 'LineStyle', '--');

% We're going to plot another thing, let's not erase out original line:
hold on;
t2 = 0:0.01:maxt/2;
h2 = plot(t2, sin(2*pi*t2/period), 'b');  % A blue color to distinguish it from the previous one
h3 = plot(t2(end), sin(2*pi*t2(end)/period), 'b', 'Marker', 'o', 'MarkerFaceColor', 'b');

nsteps=1000;
motion_per_step = 0.3;
for i=1:nsteps
	% animate the line:
	set(h2, 'YData', sin((t2+motion_per_step*i)*2*pi/period));
	% animate the dot:
	set(h3, 'YData', sin((t2(end)+motion_per_step*i)*2*pi/period));
	% Keep the x limits fixed:
	xlim([0 maxt]);
	% This command says "don't wait for a convenient time, plot on the
	% screen NOW" i.e., send all the graphics commands waiting on the queue
	% to be executed
	drawnow;
end;





