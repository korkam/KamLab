S = struct('height', {}, 'hair_length', {}, 'nationality', {});
S(1).height = 20;
S(1).hair_length = 100;
S(1).nationality = ...    % ... means next line is a continuation of the current one
	'canadian';

% Get the names of the fields in S.  The function fieldnames returns
% a cell, which has the same number of elements as there are fields in S,
% and each element will be a string, indicating the name of the field
fnames = fieldnames(S);
% Loop through each of the fields
for i=1:numel(fnames)
	% fprintf sends written text to a file. The file ID 1 (the number 1)
	% is a special file that means the command window
	% In the string that goes into fprintf
	%      %d   means "this is going to be an integer"
	%      %s   means "this is going to be a string"
	%      %g   means "this is going to be a floating point number,
	%                   please decide best to print it"
	%      %.Nf means "this is going to be a floating point number,
	%                   please give me N places after the decimal point
	%      \n   means "new line"
	%
	%  What happens if you want an '  in your printout?
	%   '' means "not the end of the string, but an ' to put IN the string"
	%  Similarly, \\ means "not the beginning of \n, but I want a \\"
	fprintf(1, 'The %d''rd field name is "%s"\n', i, fnames{i});
end;

fprintf(1, ['Here \\ is a gratuitous example of 2 floating point numbers\n', ...
	'first = %g, second = %.9f\n'], 3, 3);
	