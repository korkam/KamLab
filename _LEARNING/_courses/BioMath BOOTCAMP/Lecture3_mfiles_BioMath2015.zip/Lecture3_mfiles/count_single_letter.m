% [n_counts] = count_single_letter(str, letter)]
%
%  Returns the number of times the single letter "letter" was found in the
%  string "str"


function [n_counts] = count_single_letter(str, letter)

% find(X) will return the index of every non-zero element in the vector X

n_counts = length(find(letter==str));


