x = [1 3 4 1.2];
y = [10 20 30 50];

plot(x, y);

xlim([0 5])
ylim([0 60]);

h = plot(x, y, '-rx', 'MarkerSize', 16);

% to look at all the graphics properties, "graphics handles"
%    get(h)
% to set them
%    set(h, propertyname), e.g., set(h, 'Color', [1 0 1])
%    set(h, propertyname)  will return the possibilities
% 

%    set(h)