function [r] = ndice(n, k)
% [r] = ndice(n, k)
%
% Rolls an even n-sided die k times.  r will be a k-element vector
% containing the results
%

r = ceil(rand(1, k)*n);

