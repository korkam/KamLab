function [counts, u] = joyce(str)
% [] = joyce(str)
%
% For each letter in str, count the number of times it appears
%
% Returns counts and u, where u is the list of letters in str
%

u = unique(str(find(~isspace(str))));
% u is now a vector listing all the non-space chars in str

counts = zeros(size(u));

for y=1:length(u);    
    counts(y) = length(find(str == u(y)));
end;

clf; bar(counts);
set(gca, 'FontSize', 20);

for i=1:length(u),
    text(i, counts(i)+10, u(i), 'FontSize', 16, ...
        'Color', [1 0 0], 'HorizontalAlignment', 'center');
end;

