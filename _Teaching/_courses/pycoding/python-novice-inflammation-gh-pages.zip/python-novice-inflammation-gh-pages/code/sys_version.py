import sys
print('version is', sys.version)
