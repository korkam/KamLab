python-novice-inflammation
==========================

An introduction to Python for non-programmers using inflammation data.
Please see <https://swcarpentry.github.io/python-novice-inflammation/> for a rendered version of this material,
[the lesson template documentation][lesson-example]
for instructions on formatting, building, and submitting material,
or run `make` in this directory for a list of helpful commands.

Maintainers:

* [Trevor Bekolay][bekolay_trevor]
* [Valentina Staneva][staneva_valentina]

[lesson-example]: https://swcarpentry.github.io/lesson-example
[bekolay_trevor]: http://software-carpentry.org/team/#bekolay_trevor
[staneva_valentina]: http://software-carpentry.org/team/#staneva_valentina
