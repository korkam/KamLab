% [a] = isTurtleDown
%
% Returns 1 if the pen is down, 0 otherwise.
%


function [a] = isTurtleDown

turtle_init;

a = state.down;
