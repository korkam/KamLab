% [a] = turtleAngle([add_to_angle])
%
% Can be used to ask what the turtle's angle is, or to add to the angle
% (i.e., rotate the turtle). If called with one parameter, adds to the
% angle. If called with  no parameters, simply returns the current angle.
%
% PARAMS:
% -------
%
% add_to_angle   (optional parameter). If present, must be a single scalar
%            (i.e., a regular number). This number, in degrees not radians,
%            will get added to the turtle's angle.
%
% RETURNS:
% --------
% 
% a      Returns the current angle
%
%
% EXAMPLES:
% ---------
%
%   >> turtleAngle
%
%   ans = 
%      30
%
%
%   >> turtleAngle(5)
%
%   ans = 
%      35
% 


function [a] = turtleAngle(varargin)

turtle_init;

if nargin > 0,
	d = varargin{1};
	if ischar(d),
		nd = str2double(d);
		if isnan(nd),
			error('I didn''t understand the argument "%s"', d);
		else
			d = nd;
		end;
	end;

	state.angle = rem(rem(state.angle + d, 360)+360, 360);
	set(t_turtleHandle, 'UserData', state);
end;

a = state.angle;
