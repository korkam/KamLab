% If the turtle does not exist yet, this script initalizes the turtle and
% the figure it lives in. Places it at (0,0) with pen down, blue color,
% facing up (angle = 0).
%




global t_turtleHandle;


if isempty(t_turtleHandle) || ~ishandle(t_turtleHandle),
	figure(1);
	edges = 100;
	set(gca, 'XLim', [-edges*1.05 edges*1.05], 'YLim', [-edges*1.05 edges*1.05]);
	axis square;
	t_turtleHandle = line(0, 0);
	set(t_turtleHandle, 'Marker', 'pentagram', 'MarkerSize', 16, 'MarkerFaceColor', 'r', ...
		'MarkerEdgeColor', 'r');
	state = struct('angle', 0, 'down', 1, 'color', [0 0 1], 'edges', edges);
	set(t_turtleHandle, 'UserData', state);
end;

state = get(t_turtleHandle, 'UserData');



