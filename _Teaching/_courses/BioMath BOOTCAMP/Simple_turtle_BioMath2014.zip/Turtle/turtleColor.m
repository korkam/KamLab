% [c] = turtleColor([newcolor])
%
% Can be used to ask what the turtle's pen color is, or to set the pen
% color. If called with one parameter, sets the pen color. If called with
% no parameters, simply returns the current pen color.
%
% PARAMS:
% -------
%
% newcolor   (optional parameter). If present, must be in the form [r g b]
%            where each of r, g, and b are between 0 and 1, and express the
%            amount of red, green, and blue in the color, respectively.
%
% RETURNS:
% --------
% 
% color      Returns the current color in the format [r g b]
%
%
% EXAMPLES:
% ---------
%
%   >> turtleColor
%
%   ans = 
%      0  0  1
%
%
%   >> turtleColor([1 0 0 ])
%
%   ans = 
%      1  0  0
% 



function [c] = turtleColor(varargin)

turtle_init;
if nargin>0,
	state.color = varargin{1};
	set(t_turtleHandle, 'UserData', state);
end;

c = state.color;

