% [] = turtleDown      Sets the turtle's pen to "down" (i.e., draw as you move).

function [] = turtleDown

turtle_init;
state.down = 1;
set(t_turtleHandle, 'UserData', state);

