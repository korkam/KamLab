function [] = square2(l)

turtleDown;
sides = 4;

while sides > 0,
	turtleForward(l);
	turtleAngle 90;
	sides = sides - 1;
end;

