% [] = turtleUp      Sets the turtle's pen to "up" (i.e., do not draw).

function [] = turtleUp

turtle_init;
state.down = 0;
set(t_turtleHandle, 'UserData', state);

