function [] = square1(l)

turtleDown;

turtleForward(l);
turtleAngle 90;

turtleForward(l);
turtleAngle 90;

turtleForward(l);
turtleAngle 90;

turtleForward(l);
turtleAngle 90;



