function turtleForward(d)

turtle_init;

if ischar(d), 
	nd = str2double(d); 
	if isnan(nd),
		error('I didn''t understand the argument "%s"', d);
	else
		d = nd;
	end;
end;

edges = state.edges;

x = get(t_turtleHandle, 'XData');
y = get(t_turtleHandle, 'YData');

newx = x + d*sin(state.angle*pi/180);
newy = y + d*cos(state.angle*pi/180);

if newx > edges,  newx = edges;  end;
if newx < -edges, newx = -edges; end;
if newy > edges,  newy = edges;  end;
if newy < -edges, newy = -edges; end;

if state.down, 
	set(line([x newx], [y newy]), 'Color', state.color);
end;
set(t_turtleHandle, 'XData', newx, 'YData', newy);
drawnow;


