% [] = turtleZero    Puts the turtle at position (0, 0), facing upwards
%                    (angle=0). Does not draw as it moves to (0,0),
%                    rgardless of whether the turtle's pen was up or down.


function [] = turtleZero

turtle_init;

state.angle = 0; 
state.down  = 1;
set(t_turtleHandle, 'XData', 0, 'YData', 0, 'UserData', state);



