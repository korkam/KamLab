img1 = imread('peppers.png');
img1 = double(img1);
img1 = img1/255;
imshow(img1,[])
%%
img2 = double(imread('pout.tif'));
imshow(img2,[],'I','F')

%%
img3 = conv2(img2,fspecial('disk',5),'same');
imshow(img3,[],'i','f');
title('Averaged with a disk');

%% sharpening
subplot(1,2,1);
imshow(img2,[]);
subplot(1,2,2);
imshow(-0.2*img3+img2,[])

%% gaussian blur
blurKern = fspecial('gaussian',5,2);
subplot(1,2,2);
imshow(blurKern,[]);
subplot(1,2,1);
imshow(fspecial('disk',2),[],'i','f');
figure(gcf);
%% motion
blurKern = fspecial('motion',35,37);
img4 = conv2(img2,blurKern,'same');
subplot(1,2,1);
imshow(img2,[],'i','f');
subplot(1,2,2);
imshow(img4,[],'i','f');

%% load in circuit board image
img1 = imread('circuit.tif');
subplot(1,2,1)
imshow(img1,[],'i','f');

for ii=1:6
    switch ii
        case 1
            stringForEdgeDetector = 'canny';
        case 2
            stringForEdgeDetector = 'log';
            
        case {3,4}
            stringForEdgeDetector = 'sobel';
            
        otherwise
            stringForEdgeDetector = 'prewitt';

    end
    
    imgTemp = edge(img1,stringForEdgeDetector);
    subplot(2,3,ii);
    imshow(imgTemp,[],'i','f');
    title(stringForEdgeDetector)
end

%% segmentation of coins
img1 = double(imread('coins.png'));
imshow(img1,[],'i','f');

%% using otsu's method
img2 = (img1-min(img1(:)))./(max(img1(:))-min(img1(:)));

imhist(img2);
level = graythresh(img2);
subplot(2,2,1);
imshow(img1,[],'i','f');
subplot(2,2,2);
imshow(img2>level,[],'i','f');
title('otsu''s');
subplot(2,2,3);
THRESH = 0.121;
imshow(img2>THRESH,[],'i','f');
title(num2str(THRESH));
subplot(2,2,4);
THRESH = 0.9;
imshow(img2>THRESH,[],'i','f');
title(num2str(THRESH));
figure(gcf);

%% fill in otsu's segmentation
otsusSegment = img2>level;
subplot(1,2,1);
imshow(img2,[]);
subplot(1,2,2);
imshow(otsusSegment,[]);

filledOtsu = imfill(otsusSegment,'holes');
subplot(1,2,1);
imshow(otsusSegment,[]);
subplot(1,2,2);
imshow(filledOtsu,[]);

%% use imfindcircles
subplot(1,2,1);
imshow(img2,[],'i','f');
[centers,radii] = imfindcircles(img2,[10,80]);
 viscircles(centers,radii);   
 subplot(1,2,2);
 hist(radii);
 
 %% edge detection to segment image
 edges1 = edge(img2,'canny');
 subplot(1,2,1);
 imshow(img2,[],'i','f');
 subplot(1,2,2);
 edges2 = imfill(edges1,'holes');
 edges3 = bwmorph(edges2,'erode');
 edges4 = bwmorph(edges3,'dilate');
 % give region a unique name
 labelMatrix = bwlabel(edges4);
 % give each region a color
 coloredLabels = label2rgb(labelMatrix,'jet');
 
 imshow(coloredLabels,[],'i','f');
 figure(gcf);
    d
 outputStructure = regionprops(labelMatrix,'all');
    
