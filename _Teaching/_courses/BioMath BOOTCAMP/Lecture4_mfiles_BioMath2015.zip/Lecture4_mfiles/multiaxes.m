% example of two axes right on top of each other

clf;

% Make two identical axes atr position given by
% left, right, width, height
ax1 = axes('Position', [0.25 0.2 0.7 0.7]);
ax2 = axes('Position', [0.25 0.2 0.7 0.7]);

% Current axis is the second one, because that's the one that was made
% last
plot(1:10, randn(1,10), 'r');
set(ax2, 'YColor', 'r', 'YAxisLocation', 'right');

% to plot on the first axis, we mamke it the "current" axis
axes(ax1);
plot(1:10, 10*randn(1,10), 'b');

% NOTE: to make figure n the current figure, call "figure(n)"

% set the axis that is on top to have a transparent background:
set(ax1, 'Color', 'none');

% Get rid of the tick marks on the top and on the side that doesn't have
% the y tick labels:
set(ax1, 'Box', 'off');



set(ax2, 'Box', 'off');
