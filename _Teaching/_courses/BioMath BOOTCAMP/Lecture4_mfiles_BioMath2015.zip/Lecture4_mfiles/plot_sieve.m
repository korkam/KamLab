function [] = plot_sieve(nrows, ncols)
% [] = plot_sieve(nrows, ncols)
%
% Puts up a plot of a sieve of eratosthenes with nrows rows and ncols
% columns
%
% Stores information about # of rows and cols in the current axis'
% 'UserData' property; cross_out.m later fishes that info out.

clf;

current_row = 1;
current_col = 1;

ylim([0 nrows+1]);
xlim([0 ncols+1]);

fontsize = 20;
for i=1:nrows*ncols,
    tx = text(current_col, nrows - current_row + 1, num2str(i));
    set(tx, 'FontSize', fontsize);
    % step to next column:
    current_col = current_col + 1;
    % If we've beyond # of legal columns, step to next row and start at the
    % first column again
    if current_col > ncols,
        current_row = current_row + 1;
        current_col = 1;
    end;
end;

set(gca, 'UserData', [nrows ncols, fontsize]);
