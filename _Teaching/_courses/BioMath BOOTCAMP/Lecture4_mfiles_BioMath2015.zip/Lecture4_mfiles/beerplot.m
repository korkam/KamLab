load beerncode_data
clf;

npeople = size(beerncode, 2);
beersdrunk = zeros(1, npeople);
errorsmade = zeros(1, npeople);
graphics_handles = zeros(1, npeople);

for i=1:npeople,
    beersdrunk(i) = beerncode{2, i};
    errorsmade(i) = beerncode{4, i};
    % graphics command for putting up text:
    name = beerncode{1, i};
    graphics_handles(i) = ...
        text(beersdrunk(i), errorsmade(i), name, ...
            'HorizontalAlignment', 'center', 'FontSize', 20);
end;

% set the axes limits to span the data:
xlim([-min(beersdrunk)-1 max(beersdrunk)+1]);
ylim([-min(errorsmade)-1 max(errorsmade)+1]);

I = find(beersdrunk > 2);

M = corrcoef(beersdrunk(I)', errorsmade(I)');



fprintf('Correlation between drinking and errors is %.2f\n', ...
    M(1,2));
% (remember, corrcoef expects column vectors, that's why we transposed them
% above)

% plot(beersdrunk, errorsmade, 'o', 'MarkerSize', 20);
xlabel('beers drunk')
ylabel('errors made');
axis equal;

return;

% --------  Now make it rotate!  -----

% Rotation per step:

while 1,
    theta = 5 * pi/180;  % 5 degrees expressed in radians
    
    R = [cos(theta) sin(theta) ; -sin(theta) cos(theta)];
    
    for i=1:npeople
        position = get(graphics_handles(i), 'Position');
        newxy = R*position(1:2)';
        newposition = [newxy(1) newxy(2) 0];
        set(graphics_handles(i), 'Position', newposition);
    end;
    % Remember to make sure all our graphics commands
    % are executed after each step:
    drawnow;
end;

