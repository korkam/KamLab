function [] = cross_out(n)
% [] = cross_out(n)
%
% Puts a big red X on top of the number n previously plotted by plot_sieve.
%

userdata = get(gca, 'UserData');

nrows = userdata(1);
ncols = userdata(2);
fontsize = userdata(3);

row = ceil(n / ncols);
col = rem(n, ncols);
if col==0, col = ncols; end;

tx = text(col, nrows - row + 1, 'X');
set(tx, 'FontSize', fontsize*2, 'Color', 'r', ...
    'FontWeight', 'bold');

