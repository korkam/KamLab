% Script that uses the sieve of Eratosthenes method to figure out which
% integers are prime

nrows = 10;
ncols = 20;

plot_sieve(nrows, ncols);

% This vector will be our bag of numbers that are potentially priems
still_possible_primes = 1:nrows*ncols;

fprintf(1, 'First prime: %d\n', still_possible_primes(1));

still_possible_primes = still_possible_primes(2:end);


while ~isempty(still_possible_primes),
    fprintf(1, 'Next prime: %d\n', still_possible_primes(1));
    myprime = still_possible_primes(1);
    for i=myprime : myprime : nrows*ncols,
        if i>myprime,
            % Don't cross out graphically myprime,
            % but do cross out graphically all its multiples
            cross_out(i);
        end;
        % Do excise myprime and all multiples of myprime from the bag of primes
        u = find(still_possible_primes == i);
        % If u is empty, line 31 would return an empty vector, which we
        % don't want. If u is empty that means i was already dropped from
        % the bag of primes, so we don't need to do anything.
        if ~isempty(u),
            still_possible_primes = ...
                still_possible_primes([1:u-1 u+1:end]);
        end;
    end;
    pause;  % Wait for a keystroke from the user, just so it doesn't go too fast.
end;
