% Let's define the matrix for our dynamics. Some other examples are
% commented our here.
M = [1.433 -0.267 ; 0.267 0.767];
theta = 10*pi/180; 
R = [cos(theta) -sin(theta) ; sin(theta) cos(theta)];
% M = [1.3 -0.2 ; 0.2 0.8];
% M = M*R;
% M  = R;

% Make a grid of points:
[X, Y] = meshgrid(-200:40:200, -200:40:200);
nsteps = 12;  % this'll be the number of discrete steps that we iterate x_new = M*x_old

X0 = [X(:)' ; Y(:)'];  % We put our grid of points into an 2-by-n matrix where the first row is horiz position, second row vertical position
X1 = M*X0; % The result of going through one iteration

figure(1); clf;
subplot(1,2,1);
plot(X0(1,:), X0(2,:), 'b.');  % We plot the original data only at first
axis equal;
title('original space');

%% Plot starting and initial points for one iteration
figure(1);
cla;
h0 = plot([X0(1,:) ; X1(1,:)], [X0(2,:); X1(2,:)], '-');  % A line from starting to ending position
set(h0, 'Color', [0 0.5 0]);
hold on;
plot(X1(1,:), X1(2,:), 'b.');  % plus a blue dot at the ending position
axis equal; % let's have an equal aspect ratio
title('original space');

%% Plotting eigenvector and cartesian axes
[V, D] = eig(M);
k = add_axes([0;1], [1;0], 'k');
r = add_axes(V(:,1), V(:,2), 'r');

%% iterated points in original space
points = { ...
   'x' 100 100 ; ...
   'o' 100  50 ; ...
   'd' 100 200 ; ...
   'm' -100 -180 ; ...
};

for i=1:size(points, 1),
   symbol = points{i,1};  % get the letter
   pt     = cell2mat(points(i, 2:3))'; % and the starting point; put the starting point in a column vector
   for k=1:nsteps,
      tx = text(pt(1), pt(2), symbol, 'FontWeight', 'bold', ...
         'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', ...
         'Color', [0 0.5 0], 'Clipping', 'on'); % We put the letter on the graph, centered at the pt(1), pt(2) position taht we gave it. 'Clipping', 'on' means that if the letter falls outside the axes limits, we don't show it.
      if k==1, set(tx, 'FontSize', 1.6*get(tx, 'FontSize')); end;  % Starting point is bigger font
      pt = M*pt;  % Compute the position at the next iteration
   end;
end;



%% eigenvector space

subplot(1,2,2); cla;
X1 = D*X0;  % The iteration here is going through the diagonal matrix D
h0 = plot([X0(1,:) ; X1(1,:)], [X0(2,:); X1(2,:)], '-');
set(h0, 'Color', [0 0.5 0]);
hold on;
h1 = plot(X1(1,:), X1(2,:), 'b.');
axis equal;
xl = xlim; yl = ylim;
title('eigenvector space');

add_axes(inv(V)*V(:,1), inv(V)*V(:,2), 'r');

%%  cartesian axes
add_axes(inv(V)*[0;1],  inv(V)*[1;0], 'k');


%% iterate the position of each of the lettered points
for i=1:size(points, 1),
   symbol = points{i,1};
   pt     = inv(V)*cell2mat(points(i, 2:3))';
   for k=1:nsteps,
      tx = text(pt(1), pt(2), symbol, 'FontWeight', 'bold', ...
         'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', ...
         'Color', [0 0.5 0], 'Clipping', 'on');
      if k==1, set(tx, 'FontSize', 1.6*get(tx, 'FontSize')); end;
      pt = D*pt;
   end;
end;


