% [l] = add_axes(vec1, vec2, color)
%
% Adds two lines, stretching over the entire plot, in directions vec1 and
% vec2.
%
% PARAMETERS:
% -----------
%
%   vec1    A 2-dimensional vector
%
%   vec2    A 2-dimensional vector
%
%   color   Either a color string (e.g., 'm') or a 1-by-3 vector describing
%           rgb intensity, in units of 0 to 1 (e.g., [1 0 0] is red).
%
%
% RETURNS:
% --------
%
%   l       A handle to the line object created

function [l] = add_axes(vec1, vec2, color)

xl = xlim; yl = ylim;
mx = 2*max([xl yl]);

l = line(mx*[-vec1(1) vec1(1) NaN -vec2(1) vec2(1)], ...
   mx*[-vec1(2) vec1(2) NaN -vec2(2) vec2(2)], ...
   (min(zlim)-10)*ones(1,5), ...
   'Color', color);

xlim(xl);
ylim(yl);

