function mysquare2(x)


turtleForward(x);
turtleAngle(90);

turtleForward(x);
turtleAngle(90);

turtleForward(x);
turtleAngle(90);

turtleForward(x);
turtleAngle(90);


