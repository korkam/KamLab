function [out] = mypower(x, y)

out = 1;  % This variable will hold the output of the function once the function ends. 

% y is going to act as our counter; and we'll work downwards, from the
% initial value of y, down by one on each loop, until 1.
while y>0,
	out = out*x;
	y = y-1;  % Count down by one
end;


