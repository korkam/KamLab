function [] = quartet(n, l, k, d)


turtleAngle(-45);
subflower(n, l, k, d);
turtleAngle(45);

turtleAngle(45);
subflower(n, l, k, d);
turtleAngle(-45);

turtleAngle(135);
subflower(n, l, k, d);
turtleAngle(-135);

turtleAngle(-135);
subflower(n, l, k, d);
turtleAngle(135);


function [] = subflower(n, l, k, d)

turtleUp;
turtleForward(d)
flower(n, l, k);
turtleAngle(180);
turtleUp;
turtleForward(d)
turtleAngle(180);
