function [out] = myfactorial_recur(x)

if x==1,
	out = 1;
else
	out = x*myfactorial_recur(x-1);
end;

