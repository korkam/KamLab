function [out] = myfactorial_iter(x)

out = 1;
while x >= 1,
	out = out*x;
	x = x-1;
end;
