function [angle] = ngram(n, l)

turtleDown;

s=1;
while s<=n,
	turtleForward(l);
	turtleAngle(360/n);
	s = s+1;
end;

angle = turtleAngle;
