turtleForward(50);
turtleAngle(90);

turtleForward(50);
turtleAngle(90);

turtleForward(50);
turtleAngle(90);

turtleForward(50);
turtleAngle(90);

