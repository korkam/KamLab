function [] = flower(n, l, k)

s=1;
while s<=k,
	ngram(n, l);
	turtleAngle(360/k);
	s = s+1;
end;

