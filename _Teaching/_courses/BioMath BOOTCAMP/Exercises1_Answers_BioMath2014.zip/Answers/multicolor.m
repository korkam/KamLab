function [] = multicolor(n, l, k, d);

quartet(n, l, k, d);

turtleAngle(30);
turtleColor([0, 0.5, 0]);
quartet(n, l, k, d);

turtleAngle(30);
turtleColor([1, 0, 0]);
quartet(n, l, k, d);
