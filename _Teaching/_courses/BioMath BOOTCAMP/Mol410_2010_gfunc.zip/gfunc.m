function [g, g1, g2, g3, g4] = gfunc(x)
% [g, g1, g2, g3, g4] = gfunc(x)   Compute a function and its first 4 derivatives
%
% PARAMETERS:
%
%    x       A vector of values
%
%
% RETURNS:
%
%    g       the value of the function g(x) = 1./(1+exp(-x.^3))
%
%    g1, g2, g3, g4      1st, 2nd, 3rd, 4th derivatives of g w.r.t. x
%
% All of the g's returned will be vectors of the same length as x.
%


[f, f1, f2, f3, f4] = mysigmoid(x.^3);

g = f;

g1 = f1.*3.*x.^2;

g2 = f2.*9.*x.^4 + f1.*6.*x;

g3 = f3.*27.*x.^6 + f2.*54.*x.^3 + 6.*f1;

g4 = f4.*81.*x.^8 + f3.*324.*x.^5 + f2.*180.*x.^2;



%% mysigmoid

function [f, f1, f2, f3, f4] = mysigmoid(x)
% You can actually put more than one function inside a file. But if you do
% that, the only function that is visible outside of the file is the very
% first one. No other files, nor the command line, know anything about the
% other functions inside the file. It can be a handy way to keep code
% modular-- by putting the function "mysigmoid" inside this file, I don't
% have to worry about whether you might have some other function with the
% same "mysigmoid" name that this would clash with.

f = 1./(1+exp(-x));

f1 = f.^2.* exp(-x);

f2 = (2.*f.*f1 - f.^2).*exp(-x);

f3 = (2*f1.^2 + 2.*f.*f2 - 4*f.*f1 + f.^2).*exp(-x);

f4 = (6*f1.*f2 + 2*f.*f3 - 6*f1.^2 - 6*f.*f2 + 6*f.*f1 - f.^2).*exp(-x);


