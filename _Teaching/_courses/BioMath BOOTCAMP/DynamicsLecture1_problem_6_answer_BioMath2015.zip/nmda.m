function [V] = nmda(V0, sigma)
% Solution to problem 6 of 1-D dynamics exercises

figure(1); clf;
delta_t = 0.1;   % milliseconds
T       = 500;   % ms to simulate

% First we make our static plot pf dVdt versus V
Vstatic = -85:30;
dVdt    = compute_dVdt(Vstatic);
plot(Vstatic, dVdt, 'Color', [0 0.5 0]);
xlabel('V');
ylabel('dVdt');
% Add a black line at dVdt = 0
line([min(Vstatic) max(Vstatic)], [0 0], 'Color', 'k');
ylim([-10 10]);

% Now the blue dot for our starting point
handle = line(V0, compute_dVdt(V0), ...
    'Marker', '.', 'MarkerFaceColor', 'b', 'MarkerSize', 40); 
drawnow;

% Now we're going to do the dynamics
t = 0:delta_t: T;
% The vector V is where we'll store all the voltages that we go through as
% a function of time
V = zeros(size(t));
V(1) = V0;

for i=2:length(t),
    noise  = randn(1)*sigma*sqrt(delta_t);
    % Standard Euler, but we add the noise term
    V(i) = V(i-1) + delta_t*(compute_dVdt(V(i-1)) + noise);

    set(handle, 'Xdata', V(i), 'YData', compute_dVdt(V(i)));
    xlim([-100 40]);
    drawnow;
    if rem(i, 1000)==0,
        fprintf(1, 'At time t=%g\n', t(i));
    end;
    
end;


return;



function [dVdt] = compute_dVdt(V)
% Given a voltage V, computes and returns dVdt.
%
%  V can be a vector of values, in which case dVdt will be a vector of the
%  same size

E_leak = -80;  % millivolts
E_nmda = 0;   
g_leak = 0.2;
g_nmda = 1;
Cm     = 1;

I_leak = g_leak * (E_leak - V);
I_nmda = g_nmda * (E_nmda - V)./(1 + 0.15*exp(-0.08*V));
dVdt   = (1/Cm)*(I_leak + I_nmda);



