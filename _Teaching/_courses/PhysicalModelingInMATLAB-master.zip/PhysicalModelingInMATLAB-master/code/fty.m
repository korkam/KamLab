function dydt = f(t, y)
dydt = t + y
end