function y = f(x)
a = 4;
y = x^2 - a
end
