atob = round(0.05*a) - round(0.03*b);
a = a - atob
b = b + atob
