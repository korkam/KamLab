subplot(1,2,1)
plot(T,Y)
xlabel('T')
ylabel('Y')

subplot(1,2,2)
plot(Y,T)
xlabel('Y')
ylabel('T')
