for j=1:10
    n = j;
    series
end
