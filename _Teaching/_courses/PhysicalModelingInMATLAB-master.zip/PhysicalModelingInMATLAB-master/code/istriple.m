function res = istriple (a, b, c)
    if hypotenuse(a, b) == c
        res = 1;
    else
        res = 0;
    end
end


