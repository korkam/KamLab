function res = display_vector(X)
    X
end
