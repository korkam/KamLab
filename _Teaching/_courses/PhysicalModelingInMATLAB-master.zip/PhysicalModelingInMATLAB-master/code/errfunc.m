function res = errfunc(y)
    res = (1 + y + y^2 - y^3) / (1-y)^3 - 0.892;
end
