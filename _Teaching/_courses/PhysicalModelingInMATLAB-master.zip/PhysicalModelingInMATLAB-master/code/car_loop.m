a = 150
b = 150

for i=1:52
    car_update
end