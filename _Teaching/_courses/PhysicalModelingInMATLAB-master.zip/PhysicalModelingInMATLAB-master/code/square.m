function y = bob (x)
% SQUARE  Computes x raised to the second power.
b
y = x^2