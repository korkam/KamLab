function res = error_func(x)
    res = x^3 - x - 1;
end
