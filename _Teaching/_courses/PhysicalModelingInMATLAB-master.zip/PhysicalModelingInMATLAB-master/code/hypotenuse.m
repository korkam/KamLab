function res = hypotenuse(a, b)
    res = (a.^2 + b.^2) ^ (1/2);
end

