function res = mymap(X)
    for i=1:length(X)
        Y(i) = X(i)^2;
    end
    res = Y;
end
