function res = hypoteneuse(a, b)
    res = sqrt(a^2 + b^2)
end
