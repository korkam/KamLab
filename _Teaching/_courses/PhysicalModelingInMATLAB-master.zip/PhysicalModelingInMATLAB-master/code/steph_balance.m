function b = balance(g)
%This is a function for Evaluation 5.
p=200;
n=300;
b=(p/g)*(((g+1)^n)-1);
a=5;
disp b