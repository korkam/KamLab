function res = stiff(t, y)
    res = y^2 - y^3; 
end
