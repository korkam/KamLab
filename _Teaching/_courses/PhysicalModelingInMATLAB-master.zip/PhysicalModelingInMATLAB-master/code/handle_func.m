function res = handle_func(func)
    func(pi)
end
