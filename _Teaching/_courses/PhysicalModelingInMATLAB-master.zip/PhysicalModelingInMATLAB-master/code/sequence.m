a = 1
for i=2:10
    a = a/2
end
