function zebra=result(i,j)
zebra=sin(2*pi*i)+cos(2*pi*j);
