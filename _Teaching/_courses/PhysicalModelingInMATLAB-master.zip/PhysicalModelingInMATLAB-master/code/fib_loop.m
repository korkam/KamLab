clf
hold on

for n=3:100
    rel_error
    plot(n, ans, 'ro')
end