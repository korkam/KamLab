function reqpath = findSolLoc()
% Copyright 2014 - 2016 The MathWorks, Inc.

mypath = path;

[startIndex,~] = regexp(mypath,'MusicMixerApp');

newString = mypath(1:startIndex(1));
[semiIndex,~]  = regexp(newString,';');
if ~isempty(semiIndex)
    pathname = mypath(semiIndex(end)+1:startIndex(1)-1);
else
    pathname = mypath(1:startIndex(1)-1);
end

reqpath = [pathname 'MusicMixerApp'];

end


