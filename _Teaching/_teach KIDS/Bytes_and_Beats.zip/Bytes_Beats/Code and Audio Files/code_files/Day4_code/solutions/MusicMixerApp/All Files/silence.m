function s = silence(str)
% Copyright 2014 - 2016 The MathWorks, Inc.

    s = strcmp(str,'X');
end