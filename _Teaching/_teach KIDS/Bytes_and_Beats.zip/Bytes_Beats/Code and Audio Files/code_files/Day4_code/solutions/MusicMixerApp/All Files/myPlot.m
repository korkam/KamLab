function myPlot(handles)
% Copyright 2014 - 2016 The MathWorks, Inc.

cla
set(handles.startText,'Visible','off')
set(handles.axes1,'Visible','on')

if ~isempty(handles.notes)
    song = [];
    input0 = createCell(handles.notes);
    
    for k = 1: length(input0)
        
        str0 = char (input0{k});
        if strcmpi(str0,'X')
            m = audioread('silence_40000.wav');
        else
            contents = cellstr(get(handles.gvtlist,'String'));
            switch get(handles.gvtlist,'Value')
                case 1
                    inst = contents{get(handles.gvtlist,'Value')};
                    inst = inst(1:6);
                case 2
                    inst = contents{get(handles.gvtlist,'Value')};
                    inst = inst(1:7);
                case 3
                    inst = contents{get(handles.gvtlist,'Value')};
                    inst = inst(1:6);
            end
            try
                [m, Fs] = audioread([inst, '_', str0, '_40000.wav']);
            catch
                errordlg(['Cannot find the ' str0 ' note for ' inst]);
                return
            end
        end
        song = [song;m];
    end
    plot(handles.axes1,song)
end
hold on

if isfield(handles,'filename')
    for k = 1:numel(handles.filename)
        b = ['beats' num2str(k)];
        percussion = createTunes_perc(handles.(b),handles.filename{k});   
        plot(handles.axes1,percussion)
    end
end
hold off
set(handles.axes1,'Color','k')
set(gca, 'TickLength', [0 0]);
set(gca,'XTickLabel',[])
set(gca,'YTickLabel',[])
axis tight