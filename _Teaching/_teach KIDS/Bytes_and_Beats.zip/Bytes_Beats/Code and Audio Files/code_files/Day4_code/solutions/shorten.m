% Copyright 2014 - 2016 The MathWorks, Inc.

[y,Fs] = audioread('guitar_C3_very-long_piano_normal.mp3');
 
new_len = 20000;

y1 = y (1:new_len);
 
audiowrite('guitar_C3_20000.wav',y1,Fs);
