% Copyright 2014 - 2016 The MathWorks, Inc.

% Read sound files of length 20000
[y1,Fs] = audioread('guitar_A3_20000.wav');
[y2,Fs] = audioread('snare_drum_D_20000.wav');

% When adding two arrays the length should be the same
y= y1+y2;
audiowrite('merged_file.wav',y,Fs);


