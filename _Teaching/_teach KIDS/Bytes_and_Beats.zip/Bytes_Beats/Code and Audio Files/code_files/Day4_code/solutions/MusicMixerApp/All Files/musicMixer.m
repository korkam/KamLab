function varargout = musicMixer(varargin)
% MUSICMIXER MATLAB code for musicMixer.fig
%      MUSICMIXER, by itself, creates a new MUSICMIXER or raises the existing
%      singleton*.
%
%      H = MUSICMIXER returns the handle to a new MUSICMIXER or the handle to
%      the existing singleton*.
%
%      MUSICMIXER('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MUSICMIXER.M with the given input arguments.
%
%      MUSICMIXER('Property','Value',...) creates a new MUSICMIXER or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before musicMixer_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to musicMixer_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help musicMixer

% Last Modified by GUIDE v2.5 11-Nov-2015 20:41:34
% Copyright 2014 - 2016 The MathWorks, Inc.

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @musicMixer_OpeningFcn, ...
    'gui_OutputFcn',  @musicMixer_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before musicMixer is made visible.
function musicMixer_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to musicMixer (see VARARGIN)

% Choose default command line output for musicMixer
handles.output = hObject;
% set(findobj(handles.figure1),'Units','Normalized')
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes musicMixer wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = musicMixer_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


function music_notes_Callback(hObject, eventdata, handles)
% hObject    handle to music_notes (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of music_notes as text
%        str2double(get(hObject,'String')) returns contents of music_notes as a double



% --- Executes during object creation, after setting all properties.
function music_notes_CreateFcn(hObject, eventdata, handles)
% hObject    handle to music_notes (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in tune.
function tune_Callback(hObject, eventdata, handles)
% hObject    handle to tune (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function perc1_Callback(hObject, eventdata, handles)
% hObject    handle to perc1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of perc1 as text
%        str2double(get(hObject,'String')) returns contents of perc1 as a double


% --- Executes during object creation, after setting all properties.
function perc1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to perc1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function perc2_Callback(hObject, eventdata, handles)
% hObject    handle to perc2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of perc2 as text
%        str2double(get(hObject,'String')) returns contents of perc2 as a double


% --- Executes during object creation, after setting all properties.
function perc2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to perc2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in ps2.
function ps2_Callback(hObject, eventdata, handles)
% hObject    handle to ps2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
text = get(handles.perc2,'String');
newString = [text ' X'];
set(handles.perc2,'String',newString);

% --- Executes on button press in pt2.
function pt2_Callback(hObject, eventdata, handles)
% hObject    handle to pt2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
text = get(handles.perc2,'String');
newString = [text ' P2'];
set(handles.perc2,'String',newString);

% --- Executes on button press in ps1.
function ps1_Callback(hObject, eventdata, handles)
% hObject    handle to ps1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
text = get(handles.perc1,'String');
newString = [text ' X'];
set(handles.perc1,'String',newString);

% --- Executes on button press in pt1.
function pt1_Callback(hObject, eventdata, handles)
% hObject    handle to pt1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
text = get(handles.perc1,'String');
newString = [text ' P1'];
set(handles.perc1,'String',newString);


% --- Executes on button press in playSeq1.
function playSeq1_Callback(hObject, eventdata, handles)
% hObject    handle to playSeq1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(hObject,'Enable','inactive');
set(handles.pushbutton36,'Enable','inactive');
set(handles.playSeq2,'Enable','inactive');
set(handles.playSeq3,'Enable','inactive');
set(handles.playAll,'Enable','inactive');

beats = get(handles.perc1,'String');
if isempty(beats)
    msgbox('There are no beats to play. Let us add some beats first','Message')
    set(hObject,'Enable','on');
    set(handles.pushbutton36,'Enable','on');
    set(handles.playSeq2,'Enable','on');
    set(handles.playSeq3,'Enable','on');
    set(handles.playAll,'Enable','on');
    return
end
[song,result] = createTunes_perc(beats,handles.filename{1});
set(handles.startText,'Visible','off')
set(handles.axes1,'Visible','on')
cla
plot(handles.axes1,song)
set(handles.axes1,'Color','k')
set(gca, 'TickLength', [0 0]);
set(gca,'XTickLabel',[])
set(gca,'YTickLabel',[])
axis tight
if result == 0
else
    playSound(result);
end
set(hObject,'Enable','on');
set(handles.pushbutton36,'Enable','on');
set(handles.playSeq2,'Enable','on');
set(handles.playSeq3,'Enable','on');
set(handles.playAll,'Enable','on');


% --- Executes on button press in playSeq2.
function playSeq2_Callback(hObject, eventdata, handles)
% hObject    handle to playSeq2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(hObject,'Enable','inactive');
set(handles.pushbutton36,'Enable','inactive');
set(handles.playSeq1,'Enable','inactive');
set(handles.playSeq3,'Enable','inactive');
set(handles.playAll,'Enable','inactive');

beats = get(handles.perc2,'String');
if isempty(beats)
    msgbox('There are no beats to play. Let us add some beats first','Message')
    set(hObject,'Enable','on');
    set(handles.pushbutton36,'Enable','on');
    set(handles.playSeq1,'Enable','on');
    set(handles.playSeq3,'Enable','on');
    set(handles.playAll,'Enable','on');
    return
end
[song,result] = createTunes_perc(beats,handles.filename{2});
set(handles.startText,'Visible','off')
set(handles.axes1,'Visible','on')
cla
plot(handles.axes1,song)
set(handles.axes1,'Color','k')
set(gca, 'TickLength', [0 0]);
set(gca,'XTickLabel',[])
set(gca,'YTickLabel',[])
axis tight
if result == 0
else
    playSound(result);
end
set(hObject,'Enable','on');
set(handles.pushbutton36,'Enable','on');
set(handles.playSeq1,'Enable','on');
set(handles.playSeq3,'Enable','on');
set(handles.playAll,'Enable','on');


% --- Executes on button press in playSeq3.
function playSeq3_Callback(hObject, eventdata, handles)
% hObject    handle to playSeq3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(hObject,'Enable','inactive');
set(handles.pushbutton36,'Enable','inactive');
set(handles.playSeq1,'Enable','inactive');
set(handles.playSeq2,'Enable','inactive');
set(handles.playAll,'Enable','inactive');

beats = get(handles.perc3,'String');
if isempty(beats)
    msgbox('There are no beats to play. Let us add some beats first','Message')
    set(hObject,'Enable','on');
    set(handles.pushbutton36,'Enable','on');
    set(handles.playSeq1,'Enable','on');
    set(handles.playSeq2,'Enable','on');
    set(handles.playAll,'Enable','on');
    return
end
[song,result] = createTunes_perc(beats,handles.filename{3});
set(handles.startText,'Visible','off')
set(handles.axes1,'Visible','on')
cla
plot(handles.axes1,song)
set(handles.axes1,'Color','k')
set(gca, 'TickLength', [0 0]);
set(gca,'XTickLabel',[])
set(gca,'YTickLabel',[])
axis tight
if result == 0
else
    playSound(result);
end
set(hObject,'Enable','on');
set(handles.pushbutton36,'Enable','on');
set(handles.playSeq1,'Enable','on');
set(handles.playSeq2,'Enable','on');
set(handles.playAll,'Enable','on');


% --- Executes on button press in reset.
function reset_Callback(hObject, eventdata, handles)
% hObject    handle to reset (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.perc2,'String','');
set(handles.perc1,'String','');
set(handles.music_notes,'String','');
set(handles.startText,'Visible','on')
set(handles.axes1,'Visible','off')
set(handles.percmenu1,'Value',1);
set(handles.percmenu2,'Value',1);
set(handles.percmenu3,'Value',1);
percmenu1_Callback(handles.percmenu1,eventdata,handles)
percmenu2_Callback(handles.percmenu2,eventdata,handles)
percmenu3_Callback(handles.percmenu3,eventdata,handles)
set(handles.playAll,'Enable','on');
set(handles.playSeq1,'Enable','on');
set(handles.playSeq2,'Enable','on');
set(handles.playSeq3,'Enable','on');
set(handles.pushbutton36,'Enable','on');


% --- Executes on button press in playAll.
function playAll_Callback(hObject, eventdata, handles)
% hObject    handle to playAll (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(hObject,'Enable','inactive');
set(handles.playSeq1,'Enable','inactive');
set(handles.playSeq2,'Enable','inactive');
set(handles.playSeq3,'Enable','inactive');
set(handles.pushbutton36,'Enable','inactive');
handles.beats2 = get(handles.perc2,'String');
handles.beats1 = get(handles.perc1,'String');
handles.beats3 = get(handles.perc3,'String');
handles.notes = get(handles.music_notes,'String');
[~,result] = createTunes_all(handles);
guidata(hObject, handles);
if result ~=0
    myPlot(handles)
    playSound(result);
end
set(hObject,'Enable','on');
set(handles.playSeq1,'Enable','on');
set(handles.playSeq2,'Enable','on');
set(handles.playSeq3,'Enable','on');
set(handles.pushbutton36,'Enable','on');



% --- Executes on selection change in gvtlist.
function gvtlist_Callback(hObject, eventdata, handles)
% hObject    handle to gvtlist (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns gvtlist contents as cell array
%        contents{get(hObject,'Value')} returns selected item from gvtlist


% --- Executes during object creation, after setting all properties.
function gvtlist_CreateFcn(hObject, eventdata, handles)
% hObject    handle to gvtlist (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in perc1list.
function perc1list_Callback(hObject, eventdata, handles)
% hObject    handle to perc1list (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns perc1list contents as cell array
%        contents{get(hObject,'Value')} returns selected item from perc1list


% --- Executes during object creation, after setting all properties.
function perc1list_CreateFcn(hObject, eventdata, handles)
% hObject    handle to perc1list (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in perc2list.
function perc2list_Callback(hObject, eventdata, handles)
% hObject    handle to perc2list (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns perc2list contents as cell array
%        contents{get(hObject,'Value')} returns selected item from perc2list


% --- Executes during object creation, after setting all properties.
function perc2list_CreateFcn(hObject, eventdata, handles)
% hObject    handle to perc2list (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in percmenu1.
function percmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to percmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns percmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from percmenu1
contents = cellstr(get(hObject,'String'));
if ~strncmpi(contents{get(hObject,'Value')},'Select', 6)
    set(handles.pt1,'Enable','on')
    set(handles.ps1,'Enable','on')
    set(handles.playSeq1,'Enable','on')
    set(handles.text5,'Enable','on')
    if strncmpi(contents{get(hObject,'Value')},'windchimes',4)
        handles.filename{1} = 'windchimes_40000.wav';
    else
    handles.filename{1} = [contents{get(hObject,'Value')} '_40000.wav'];
    end   
else
    set(handles.pt1,'Enable','inactive')
    set(handles.ps1,'Enable','inactive')
    set(handles.playSeq1,'Enable','inactive')
    set(handles.text5,'Enable','off')
    set(handles.perc1,'String','')    
end
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function percmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to percmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in percmenu2.
function percmenu2_Callback(hObject, eventdata, handles)
% hObject    handle to percmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns percmenu2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from percmenu2
contents = cellstr(get(hObject,'String'));
if ~strncmpi(contents{get(hObject,'Value')},'Select', 6)
    set(handles.pt2,'Enable','on')
    set(handles.ps2,'Enable','on')
    set(handles.playSeq2,'Enable','on')
    set(handles.text6,'Enable','on')
         if strncmpi(contents{get(hObject,'Value')},'windchimes',4)
        handles.filename{2} = 'windchimes_40000.wav';
    else
    handles.filename{2} = [contents{get(hObject,'Value')} '_40000.wav'];
    end
else
    set(handles.pt2,'Enable','inactive')
    set(handles.ps2,'Enable','inactive')
    set(handles.playSeq2,'Enable','inactive')
    set(handles.text6,'Enable','off')
    set(handles.perc2,'String','')    
end
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function percmenu2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to percmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
set(hObject,'Enable','on')

% --- Executes during object creation, after setting all properties.
function playSeq1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to playSeq1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
I = imread('playSmall.jpg');
I = imresize(I,[30 30]);
set(hObject,'cdata',I)


% --- Executes during object creation, after setting all properties.
function playSeq2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to playSeq2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
I = imread('playSmall.jpg');
I = imresize(I,[30 30]);
set(hObject,'cdata',I)


% --- Executes during object creation, after setting all properties.
function playAll_CreateFcn(hObject, eventdata, handles)
% hObject    handle to playAll (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
handles.images.PA = imread('playAll.jpg');
handles.images.PA = imresize(handles.images.PA,[95 95]);
set(hObject,'cdata',handles.images.PA)
guidata(hObject, handles)


% --- Executes during object creation, after setting all properties.
function startText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to startText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function text3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to text3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called



% --- Executes on button press in pushbutton19.
function pushbutton19_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton19 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function pushbutton19_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pushbutton19 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
I = imread('red.jpg');
I = imresize(I,[41 41]);
set(hObject,'cdata',I)


% --- Executes during object creation, after setting all properties.
function pt1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pt1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
I = imread('red_little.jpg');
I = imresize(I,[15 15]);
set(hObject,'cdata',I)


% --- Executes on button press in ps3.
function ps3_Callback(hObject, eventdata, handles)
% hObject    handle to ps3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
text = get(handles.perc3,'String');
newString = [text ' X'];
set(handles.perc3,'String',newString);

% --- Executes on button press in pt3.
function pt3_Callback(hObject, eventdata, handles)
% hObject    handle to pt3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
text = get(handles.perc3,'String');
newString = [text ' P3'];
set(handles.perc3,'String',newString);

% --- Executes on selection change in percmenu3.
function percmenu3_Callback(hObject, eventdata, handles)
% hObject    handle to percmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns percmenu3 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from percmenu3
contents = cellstr(get(hObject,'String'));
if ~strncmpi(contents{get(hObject,'Value')},'Select', 6)
    set(handles.pt3,'Enable','on')
    set(handles.ps3,'Enable','on')
    set(handles.playSeq3,'Enable','on')
    set(handles.text7,'Enable','on')
    if strncmp(contents{get(hObject,'Value')},'windchimes',4)
        handles.filename{3} = 'windchimes_40000.wav';
    else
    handles.filename{3} = [contents{get(hObject,'Value')} '_40000.wav'];
    end
else
    set(handles.pt3,'Enable','inactive')
    set(handles.ps3,'Enable','inactive')
    set(handles.playSeq3,'Enable','inactive')
    set(handles.text7,'Enable','off')
    set(handles.perc3,'String','')
end
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function percmenu3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to percmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
set(hObject,'Enable','on')


function perc3_Callback(hObject, eventdata, handles)
% hObject    handle to perc3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of perc3 as text
%        str2double(get(hObject,'String')) returns contents of perc3 as a double


% --- Executes during object creation, after setting all properties.
function perc3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to perc3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% --- Executes during object creation, after setting all properties.
function clear2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to clear2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
I = imread('arrowLittle.jpg');
I = imresize(I,[12 12]);
set(hObject,'cdata',I)


% --- Executes on button press in clear2.
function clear2_Callback(hObject, eventdata, handles)
% hObject    handle to clear2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
values = get(handles.perc2,'String');
if ~isempty(values)
    if strcmpi(values(end-1:end),' X')
        newString = values(1:end-2);
    else
        newString = values(1:end-3);
    end
    set(handles.perc2,'String',newString);
end


% --- Executes during object creation, after setting all properties.
function clear3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to clear3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
I = imread('arrowLittle.jpg');
I = imresize(I,[12 12]);
set(hObject,'cdata',I)


% --- Executes on button press in clear3.
function clear3_Callback(hObject, eventdata, handles)
% hObject    handle to clear3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
values = get(handles.perc3,'String');
if ~isempty(values)
    if strcmpi(values(end-1:end),' X')
        newString = values(1:end-2);
    else
        newString = values(1:end-3);
    end
    set(handles.perc3,'String',newString);
end


% --- Executes on button press in clear5.
function clear5_Callback(hObject, eventdata, handles)
% hObject    handle to clear5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
values = get(handles.perc1,'String');
if ~isempty(values)
    if strcmpi(values(end-1:end),' X')
        newString = values(1:end-2);
    else
        newString = values(1:end-3);
    end
    set(handles.perc1,'String',newString);
end


% --- Executes during object creation, after setting all properties.
function clear5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to clear5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
I = imread('arrowLittle.jpg');
I = imresize(I,[12 12]);
set(hObject,'cdata',I)


% --- Executes on button press in pushbutton36.
function pushbutton36_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton36 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(hObject,'Enable','inactive');
set(handles.playSeq1,'Enable','inactive');
set(handles.playSeq2,'Enable','inactive');
set(handles.playSeq3,'Enable','inactive');
set(handles.playAll,'Enable','inactive');
song = [];
handles.notes = get(handles.music_notes,'String');
if ~isempty(handles.notes)
    input0 = createCell(handles.notes);
    
    for k = 1: length(input0)
        
        str0 = char (input0{k});
        if strcmpi(str0,'X')
            m = audioread('silence_40000.wav');
        else
            contents = cellstr(get(handles.gvtlist,'String'));
            switch get(handles.gvtlist,'Value')
                case 1
                    inst = contents{get(handles.gvtlist,'Value')};
                    inst = inst(1:6);
                case 2
                    inst = contents{get(handles.gvtlist,'Value')};
                    inst = inst(1:7);
                case 3
                    inst = contents{get(handles.gvtlist,'Value')};
                    inst = inst(1:6);
            end
            try
                [m, Fs] = audioread([inst, '_', str0, '_40000.wav']);
            catch
                errordlg(['Cannot find the ' str0 ' note for ' inst],'Please Check');
                set(hObject,'Enable','on');
                set(handles.playSeq1,'Enable','on');
                set(handles.playSeq2,'Enable','on');
                set(handles.playSeq3,'Enable','on');
                set(handles.playAll,'Enable','on');
                return
            end
        end
        song = [song;m];
    end
    result = [findSolLoc '\myTune.wav'];
    audiowrite(result,song,Fs);   
    set(handles.startText,'Visible','off')
    set(handles.axes1,'Visible','on')
    plot(handles.axes1,song)
    set(handles.axes1,'Color','k')
    set(gca, 'TickLength', [0 0]);
    set(gca,'XTickLabel',[])
    set(gca,'YTickLabel',[])
    axis tight
    playSound(result);
end
set(hObject,'Enable','on');
set(handles.playSeq1,'Enable','on');
set(handles.playSeq2,'Enable','on');
set(handles.playSeq3,'Enable','on');
set(handles.playAll,'Enable','on');

       


% --- Executes during object creation, after setting all properties.
function playSeq3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to playSeq3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
I = imread('playSmall.jpg');
I = imresize(I,[30 30]);
set(hObject,'cdata',I)

% --- Executes during object creation, after setting all properties.
function pushbutton36_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pushbutton36 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
I = imread('playSmall.jpg');
I = imresize(I,[30 30]);
set(hObject,'cdata',I)


% --- Executes during object creation, after setting all properties.
function pt2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pt2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
I = imread('red_little.jpg');
I = imresize(I,[15 15]);
set(hObject,'cdata',I)


% --- Executes during object creation, after setting all properties.
function pt3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pt3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
I = imread('red_little.jpg');
I = imresize(I,[15 15]);
set(hObject,'cdata',I)
