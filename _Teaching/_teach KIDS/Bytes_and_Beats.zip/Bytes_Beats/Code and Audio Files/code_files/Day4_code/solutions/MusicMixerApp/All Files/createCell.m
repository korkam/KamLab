function myCell = createCell(text)
% Copyright 2014 - 2016 The MathWorks, Inc.

spaceLoc = regexp(text,' ');
if ~isempty(spaceLoc)
    if spaceLoc(1) == 1
        if numel(spaceLoc) == 1
            myCell{1} = text;
            return
        end
        spaceLoc(1) = [];
        spaceLoc = spaceLoc-1;
        text(1) = [];
    end
    myCell{1} = text(1:spaceLoc(1)-1);
    c = 1;
    for i = 2:length(spaceLoc)
        x = text(spaceLoc(i-1)+1:spaceLoc(i)-1);
        if isempty(x)
            continue
        end
        c = c+1;
        myCell{c} = x;
    end
    x = text(spaceLoc(end)+1:end);
        if ~isempty(x)
            myCell{end+1} = x;
        end
     
else
    myCell{1} = text;
end