function playSound (filename)
% Copyright 2014 - 2016 The MathWorks, Inc.

[data, fs] = audioread(filename);
obj = audioplayer(data, fs);
playblocking(obj);

