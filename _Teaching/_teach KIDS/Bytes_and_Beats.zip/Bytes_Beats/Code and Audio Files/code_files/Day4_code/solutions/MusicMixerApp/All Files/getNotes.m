function myCell = createCell(text)
% Copyright 2014 - 2016 The MathWorks, Inc.

spaceLoc = regexp(text,' ');
if ~isempty(spaceLoc)
    if spaceLoc(1) == 1
        spaceLoc(1) = [];
        spaceLoc = spaceLoc-1;
        text(1) = [];
    end
    myCell{1} = text(1:spaceLoc(1)-1);
    for i = 2:length(spaceLoc)
        myCell{i} = text(spaceLoc(i-1)+1:spaceLoc(i)-1);
    end
    myCell{end+1} = text(spaceLoc(end)+1:end);
else
    myCell{1} = text;
end