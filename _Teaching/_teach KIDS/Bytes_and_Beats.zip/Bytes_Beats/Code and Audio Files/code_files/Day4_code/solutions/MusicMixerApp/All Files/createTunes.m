function [song,result] = createTunes(text,instrument)
% Copyright 2014 - 2016 The MathWorks, Inc.

song = [];

spaceLoc = regexp(text,' ');
if ~isempty(spaceLoc)
    input{1} = text(1:spaceLoc(1)-1);
    for i = 2:length(spaceLoc)
        input{i} = text(spaceLoc(i-1)+1:spaceLoc(i)-1);
    end
    input{end+1} = text(spaceLoc(end)+1:end);
else
    input{1} = text;
end



for i = 1: length(input)
    
    str2 =char (input{i});
    filename = [instrument '_' str2 '_40000.wav'];
    [g,Fs] = audioread(filename);
    song = [song; g];
    
end

filename = [findSolLoc '\myTune.wav'];
audiowrite(filename,song,Fs);
result = filename;
