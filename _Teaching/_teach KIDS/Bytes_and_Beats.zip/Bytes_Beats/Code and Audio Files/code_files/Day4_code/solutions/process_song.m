% Copyright 2014 - 2016 The MathWorks, Inc.

cabasa = getNotes('C C C C C C C C C C C C C C C C');
tambourine= getNotes('T X T X T X T X T X T X T X T X');
violin = getNotes('G3 G3 D3 D3 E4 F4 G4 E4 D3 C3 C3 B3 B3 A3 A3 G3');
song = zeros(20000,1);

for j =1 :2

for i = 1: 16

%First Instrument
      str1 =char (cabasa(i));
      if silence(str1)
         c = audioread('silence_40000.wav');
      else
         [c, Fs] = audioread('cabasa_40000.wav');
      end
      
%Second Instrument  
      str2 =char (violin(i));
      if silence(str2)
         g = audioread('silence_40000.wav');
      else
         [g,Fs] = audioread(['guitar_' str2 '_40000.wav']);
      end  
%      
 %Third Instrument      
     str3 =char (tambourine(i));
      if silence(str3)
        t = audioread('silence_40000.wav');
      else
        [t, Fs] = audioread('tambourine_40000.wav');
      end
    
%Add all the instruments
      x = c + g + t ;
       % x= c +t;
%Add the previous iteration
    song = [song; x];
    
end
end

audiowrite ('my_song.wav',song,Fs);
playSound('my_song.wav');