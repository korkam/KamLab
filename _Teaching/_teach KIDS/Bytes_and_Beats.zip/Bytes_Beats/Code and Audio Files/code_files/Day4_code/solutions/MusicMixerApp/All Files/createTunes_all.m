function [song,result] = createTunes_all(handles)
% Copyright 2014 - 2016 The MathWorks, Inc.

song = [];

if ~isempty(handles.notes)
    input0 = createCell(handles.notes);
end

idx = zeros(1,3);
filename = cell(3,1);
for k = 1:3
    if isfield(handles,['beats' num2str(k)])
        fieldname = ['beats' num2str(k)];
        if ~isempty(handles.(fieldname))
            try
                input(k,:) = createCell(handles.(fieldname));
                filename{k,:} = handles.filename{k};
                idx(k) = 1;
            catch
                errordlg({'The number of beats dont match for all the instruments'})
                result = 0;
                return
            end
        end
    end
end

if exist('input0','var') & ~exist('input','var')
    nob = length(input0);
elseif ~exist('input0','var') & exist('input','var')
    nob = size(input,2);
elseif ~exist('input0','var') & ~exist('input','var')
    nob = 0;
elseif exist('input0','var') & exist('input','var')
    
    if length(input0) ~= size(input,2)
        nob = 0;
        errordlg({'The number of beats dont match for all the instruments'})
        result = 0;
        return
    else
        nob = length(input0);
    end
end


valid = find(idx);
m = 0;

if nnz(valid) > 0 | exist('input0','var')
    
    for k = 1: nob
        pa = 0;
        
        if exist('input0','var')
            str0 = char (input0{k});
            if strcmpi(str0,'X')
                m = audioread('silence_40000.wav');
            else
                contents = cellstr(get(handles.gvtlist,'String'));
                switch get(handles.gvtlist,'Value')
                    case 1
                        inst = contents{get(handles.gvtlist,'Value')};
                        inst = inst(1:6);
                    case 2
                        inst = contents{get(handles.gvtlist,'Value')};
                        inst = inst(1:7);
                    case 3
                        inst = contents{get(handles.gvtlist,'Value')};
                        inst = inst(1:6);
                end
                try
                    [m, Fs] = audioread([inst, '_', str0, '_40000.wav']);
                catch
                    errordlg(['Cannot find the ' str0 ' note for ' inst],'Please Check');
                    result = 0;
                    return
                end
                
            end
        else
            m = zeros(40000,1);
        end
        
        if nnz(valid) > 0
            for n = 1:length(valid)
                str = char(input{valid(n),k});
                if strcmpi(str,'X')
                    p = audioread('silence_40000.wav');
                else
                    [p, Fs] = audioread(filename{valid(n),:});
                end
                pa = pa + p;
            end
            x = m + pa;
            song = [song;x];
        else
            song = [song;m];
        end
        
        
    end
    result = [findSolLoc '\myTune.wav'];
    audiowrite(result,song,Fs);
else
    result = 0;
end





