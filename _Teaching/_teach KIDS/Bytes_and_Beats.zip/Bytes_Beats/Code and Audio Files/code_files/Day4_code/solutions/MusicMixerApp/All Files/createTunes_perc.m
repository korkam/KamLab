function [song,result] = createTunes_perc(text,filename)
% Copyright 2014 - 2016 The MathWorks, Inc.

song = [];

if length(text)>1
    text(1) = [];
    
    spaceLoc = regexp(text,' ');
    if ~isempty(spaceLoc)
        input{1} = text(1:spaceLoc(1)-1);
        for i = 2:length(spaceLoc)
            input{i} = text(spaceLoc(i-1)+1:spaceLoc(i)-1);
        end
        input{end+1} = text(spaceLoc(end)+1:end);
    else
        input{1} = text;
    end
    
    for i = 1: length(input)
        str1 =char (input{i});
        if strcmpi(str1,'X')
            c = audioread('silence_40000.wav');
        else
            [c, Fs] = audioread(filename);
        end
        song = [song; c];
    end
    result = [findSolLoc '\myPerc.wav'];
    audiowrite(result,song,Fs);
    else
    result = 0;
end