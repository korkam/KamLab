% Copyright 2014 - 2016 The MathWorks, Inc.

recObj = audiorecorder;
recordblocking(recObj, 5);

play(recObj);
y = getaudiodata(recObj);
