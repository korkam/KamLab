% Copyright 2014 - 2016 The MathWorks, Inc.

highEnd = 4.5;
lowEnd = 0.05;
f = 131;
    
while(1)
    reading = board.readPin ('A0');
    board.playTone('D3', f*reading,1);
end
    