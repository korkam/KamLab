% Copyright 2014 - 2016 The MathWorks, Inc.

while(1)
    board.readPin ('A2')
end