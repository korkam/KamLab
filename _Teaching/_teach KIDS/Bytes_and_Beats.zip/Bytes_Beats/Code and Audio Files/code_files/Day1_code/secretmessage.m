% Copyright 2014 - 2016 The MathWorks, Inc.
code = [1 7 2 6 11 13 5 16 10];
secret = 'xlshooypwepnhckn';
