function varargout = soundUI(varargin)
% SOUNDUI MATLAB code for soundUI.fig
%      SOUNDUI, by itself, creates a new SOUNDUI or raises the existing
%      singleton*.
%
%      H = SOUNDUI returns the handle to a new SOUNDUI or the handle to
%      the existing singleton*.
%
%      SOUNDUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SOUNDUI.M with the given input arguments.
%
%      SOUNDUI('Property','Value',...) creates a new SOUNDUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before soundUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to soundUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help soundUI

% Last Modified by GUIDE v2.5 25-Nov-2014 10:08:00
% Copyright 2014 - 2016 The MathWorks, Inc.

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @soundUI_OpeningFcn, ...
                   'gui_OutputFcn',  @soundUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before soundUI is made visible.
function soundUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to soundUI (see VARARGIN)

% Choose default command line output for soundUI
handles.output = hObject;
load handel.mat
audiowrite('handel.wav',[y;y;y;y;y;y], Fs)

handles.AFR = dsp.AudioFileReader ('handel.wav');
handles.AP = dsp.AudioPlayer('SampleRate',handles.AFR.SampleRate);
set(handles.slider1,'value',0);
set(handles.Volume,'value',0.5);
handles.t = 0;

x = 1:1024;
handles.z = plot(handles.axes1, x',zeros(size(x)));
axis([1024-1100 1100  -2 2])
axis manual; grid on;
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes soundUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = soundUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in Play.
function Play_Callback(hObject, eventdata, handles)
% hObject    handle to Play (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Stop; Stop = 0
while ~isDone(handles.AFR) && Stop == 0
    for k=1:5
        
        vol = 2*get(handles.Volume,'value');
        N = get(handles.slider1,'value');
        audio = step (handles.AFR);
        %audiok(:,:,k) = audio;
        rnge = max(max(audio)) - min(min(audio));
        noise = 1.5*abs(rnge*(1-N))*randn(size(audio));
        step(handles.AP, vol*(audio+noise));
%         N = N+.03;
%         if N>1
%             N=1;
%             
%         end
        set(handles.z,'YData',mean(vol*(audio+noise),2)');
        %set(z,'YData',mean(mean(audio,3),2)');
        drawnow;
        
    end
end
%pause(handles.AP.QueueDuration);
release (handles.AFR);
release (handles.AP);

% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function Volume_Callback(hObject, eventdata, handles)
% hObject    handle to Volume (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function Volume_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Volume (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes during object creation, after setting all properties.
function axes1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes1


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
release (handles.AFR);
release (handles.AP);
% Hint: delete(hObject) closes the figure
delete(hObject);


% --- Executes on button press in Stop.
function Stop_Callback(hObject, eventdata, handles)
% hObject    handle to Stop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Stop; Stop = 1; 
release (handles.AFR);
release (handles.AP);
