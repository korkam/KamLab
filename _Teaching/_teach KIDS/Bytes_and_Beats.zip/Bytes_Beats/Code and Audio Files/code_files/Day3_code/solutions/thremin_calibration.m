% Copyright 2014 - 2016 The MathWorks, Inc.

while(1)
    
    v= readVoltage(obj,0)
    pause (1); 
        
end