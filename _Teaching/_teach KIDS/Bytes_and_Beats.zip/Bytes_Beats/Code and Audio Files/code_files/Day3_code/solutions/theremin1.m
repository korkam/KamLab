% Copyright 2014 - 2016 The MathWorks, Inc.
% board.Connect(4)

while(1)
    
    v= readVoltage(obj,0)
    
    
    if v>1.8
        playSound('suspended-cymbal__05_mezzo-forte_damped.mp3')
        board.writePin('D4',1);
    end
        
    if v> 1.5 && v<1.7
        playTrumpet(400*v/2);
        board.writePin('D4',0);
    end
    
    if v>1 && v<1.5
    playTrumpet(500*v/1.75);
    board.writePin('D4',1);
    end
    
    if v>0.5 && v<1
        playTrumpet (600*v/0.75);
        board.writePin('D4',0);
    end
    
    if v <0.5 && v>0.05
        playTrumpet ( 800*v / 0.25);
        board.writePin('D4',1);
        pause(1);
    end
    
    
    if v <0.09
         pause(1);
    end
 
        
end