% Copyright 2014 - 2016 The MathWorks, Inc.
% board.Connect(4)

while(1)
    
    v = readVoltage(obj,0)
    
    if v>0.18
   
    playOpenString(v*900);
        
    end
        
end