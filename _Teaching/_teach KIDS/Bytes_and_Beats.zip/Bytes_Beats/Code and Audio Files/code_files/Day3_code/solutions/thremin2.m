% Copyright 2014 - 2016 The MathWorks, Inc.

while(1)
    
    v= readVoltage(obj,0);
    
    if (v>0.25 && v<0.5)
       playSound('guitar_A2_40000.wav');
       board.writePin('D4',1);
    end
    
    if (v>0.5 && v<1)
        playSound('guitar_B3_40000.wav');
        board.writePin('D4',0) ;      
    end
    
    if (v>1 && v<1.5)
       playSound('guitar_C3_40000.wav');
    end 
    
     if (v>1.5 && v<2)
       playSound('guitar_D3_40000.wav');
     end   
        
     if (v>2 && v<2.5)
       playSound('guitar_G3_40000.wav');
    end   
        
        
end