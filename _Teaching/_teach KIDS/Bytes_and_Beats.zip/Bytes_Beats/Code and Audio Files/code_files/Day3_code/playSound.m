function playSound (filename)
% Copyright 2014 - 2016 The MathWorks, Inc.

[data, fs] = audioread(filename);
%[data, fs] = audioread('snap.wav');
obj = audioplayer(data, fs);
playblocking(obj);

