function playOpenString(freq)
%This plays an open string on the Guitar where the input argument is the
%string frequency
% Reference: Karplus-Strong Algorithm and discrete-time filters.

%   Copyright 1988-2016 The MathWorks, Inc.

%% Setup
% Begin by defining variables that we will be using later, e.g. the
% sampling frequency, the first harmonic frequency of the A string, the
% offset of each string relative to the A string.

Fs       = 44100; % Sampling rate or sampling frequency
A        = freq; % The A string of a guitar is normally tuned to 110 Hz- fundamental frequency
Eoffset  = -5; 
Doffset  = 5;
Goffset  = 10;
Boffset  = 14;
E2offset = 19;
%%
% Generate the frequency vector that we will use for analysis.
F = linspace(1/Fs, 1000, 2^12);
%%
% Generate 4 seconds of zeros to be used to generate the guitar notes.
x = zeros(Fs*4, 1);

%% Playing a Note on an Open String
%  When a guitar string is plucked or strummed, it produces a sound wave
%  with peaks in the frequency domain that are equally spaced.  These are
%  called the harmonics and they give each note a full sound.  We can
%  generate sound waves with these harmonics with discrete-time filter
%  objects.
%
% Determine the feedback delay based on the first harmonic frequency.
delay = round(Fs/A);
%%
% Generate an IIR filter whose poles approximate the harmonics of the A
% string.  The zeros are added for subtle frequency domain shaping.
b  = firls(42, [0 1/delay 2/delay 1], [0 0 1 1]);
a  = [1 zeros(1, delay) -0.5 -0.5];
%%
% Show the magnitude response of the filter.
[H,W] = freqz(b, a, F, Fs);
% plot(W, 20*log10(abs(H)));
% title('Harmonics of an open A string');
% xlabel('Frequency (Hz)');
% ylabel('Magnitude (dB)');

%%
% To generate a 4 second synthetic note first we create a vector of states
% with random numbers. Then we filter zeros using these initial states.
% This forces the random states to exit the filter shaped into the
% harmonics.

zi = rand(max(length(b),length(a))-1,1);
note = filter(b, a, x, zi);
%%
% Normalize the sound for the audioplayer.
note = note-mean(note);
note = note/max(abs(note));

soundsc(note, Fs)
% hplayer = audioplayer(note, Fs);
% play(hplayer)
% assignin('base','hplayer', hplayer);

% %% Playing a Note on a Fretted String
% %  Each fret along a guitar's neck allows the player to play a half tone
% %  higher, or a note whose first harmonic is 2^(1/12) higher.
% 
% fret  = 4;
% delay = round(Fs/(A*2^(fret/12)));
% 
% b  = firls(42, [0 1/delay 2/delay 1], [0 0 1 1]);
% a  = [1 zeros(1, delay) -0.5 -0.5];
% 
% [H,W] = freqz(b, a, F, Fs);
% hold on
% plot(W, 20*log10(abs(H)), 'r');
% title('Harmonics of the A string');
% legend('Open A string', 'A string on the 4th fret');