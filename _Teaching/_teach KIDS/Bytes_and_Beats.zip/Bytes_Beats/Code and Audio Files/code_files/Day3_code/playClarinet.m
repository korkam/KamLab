function hC =playClarinet(freq)
% Created by: Tasha Vanesian
% Used to create a clarinet sound.
cA440 = notegennophase(freq, 0.000125, 1, 7.9,.076 ,0.99 ,.032 , .013, .004, .0052, .001, .0008,.0006 ,.0002);
cenv1 = cA440.*((sin(10*pi*[0:0.000125:1]) + 100.2) * 0.1).*((sin(3*pi*[0:0.000125:1]) + 50.2) * 0.1);
cenv2 = cA440.*abs(sin(pi*[0:0.000125:1]));
cenv3 = sinenvelope(cA440, 0.000125,0.5);
% cenv4 sounds like a cross between a train whistle and a harmonica
cenv4 = cenv3.*sin(100*pi*[0:0.000125:1]);
% cenv5 sounds like a short clarinet note
cenv5 = cenv3.*sin(pi*[0:0.000125:1]);
%soundsc(cenv3, 4000);
hC = audioplayer(cenv3, 8000);
play(hC);
