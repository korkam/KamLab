function h =playTrumpet(freq)
% Copyright 2014 - 2016 The MathWorks, Inc.

tC261 = notegen(freq, 0.000125, 1, 0.17, 0, 0.63, 0, 0.57, 0, 0.98, 0, 0.56, 0, 0.38, 0.19, 0.05, 0.03, 0.02, 0.01);
tenv = tC261.*((sin(10*pi*[0:0.000125:1]) + 100.2) * 0.1).*((sin(3*pi*[0:0.000125:1]) + 50.2) * 0.1);
tenv2 = tC261.*abs(sin(pi*[0:0.000125:1]));
tenv3 = sinenvelope(tC261, 0.000125,0.5);
%soundsc(tenv3, 5000);
%plot(tenv3);hold on;
h = audioplayer(tenv3, 5000);
play(h);
