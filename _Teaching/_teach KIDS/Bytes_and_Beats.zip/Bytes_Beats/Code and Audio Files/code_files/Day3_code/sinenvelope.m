function env = sinenvelope(func, step,len)
% Copyright 2014 - 2016 The MathWorks, Inc.
%Enveloping the sine wave of a Note or Chord
sine_coefficient = [(sin((pi* [0:step:len/2.0]) / (len))) ...
                        ones(1, length([len/2.0:step:len*3/2]) - 2)...
                        abs(sin((pi* [len*3/2:step:len*2.0]) / (len)))];
env = func .* sine_coefficient;