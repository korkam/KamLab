function env = sineSound(freq, time)
% Copyright 2014 - 2015 The MathWorks, Inc.
% Enveloping the sine wave of a Note or Chord
% env = sineSound(freq)
% env = sineSound(freq, time)
    Fs = 8000; 
    Ts = 1/Fs;
if nargin == 1
    t = 0:Ts:0.2; %t2 = 0:Ts:0.2;
else
    t =0:Ts:time;
end

pure_sine = sin(2*pi*freq*t); 
step = 1/(length(t)/2); 
len =1;
sine_coefficient = [(sin((pi* [0:step:len/2.0]) / (len))) ...
                        ones(1, length([len/2.0:step:len*3/2]) - 2)...
                        abs(sin((pi* [len*3/2:step:len*2.0]) / (len)))];
% sine_coefficient = 5000;
env = pure_sine .* sine_coefficient;
soundsc(env);