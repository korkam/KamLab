function playNumber(varargin)
% Copyright 2014 - 2016 The MathWorks, Inc.
in1 = varargin{1};
notes = in1(1,:);

if nargin == 2
    d = varargin{2};  % duration (length) of note in seconds (set by user)
else
    d = 0.75;           % duration (length) of note in seconds (set automatically)
end

scale = [16.3500000000000;18.3500000000000;20.6000000000000;21.8300000000000;24.5000000000000;27.5000000000000;30.8700000000000;32.7000000000000;36.7100000000000;41.2000000000000;43.6500000000000;49;55;61.7400000000000;65.4100000000000;73.4200000000000;82.4100000000000;87.3100000000000;98;110;123.470000000000;130.810000000000;146.830000000000;164.810000000000;174.610000000000;196;220;246.940000000000;261.630000000000;293.660000000000;329.630000000000;349.230000000000;392;440;493.880000000000;523.250000000000;587.330000000000;659.250000000000;698.460000000000;783.990000000000;880;987.770000000000;1046.50000000000;1174.66000000000;1318.51000000000;1396.91000000000;1567.98000000000;1760;1975.53000000000;2093;2349.32000000000;2637.02000000000;2793.83000000000;3135.96000000000;3520;3951.07000000000;4186.01000000000;4698.63000000000;5274.04000000000;5587.65000000000;6271.93000000000;7040;7902.13000000000;];
%scale = scaleTotal(29:end);  % this is a C-major scale, with C4 = scale(1), D4 = scale(2), ... C5 = scale(8) etc. 


for k = notes
    try 
        f0 = scale(k+28);           % fundamental frequency (Hz)
        sf = 22050;                 % sample frequency (Hz)
        s = (0:1/sf:d);             % sound data preparation
        s = sin(2*pi*f0* s);        % sinusoidal modulation
        sound(s, sf);               % sound presentation
        wait = d/6; 
        pause(d + wait);
    catch
        error('You can only play numbers which are between -28 and 36.')
    end
             % waiting for sound end
end

end

