% Copyright 2014 - 2016 The MathWorks, Inc.

% Make sure you connect to the board!

board.playTone('D3', 392)
%You might need to use pause(0.2)between the playTones!
board.playTone('D3', 392)
board.playTone('D3', 440)
board.playTone('D3', 392)
board.playTone('D3', 523.3)
board.playTone('D3', 494)


