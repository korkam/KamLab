function varargout = simpleKeyBoard(varargin)
% SIMPLEKEYBOARD MATLAB code for simpleKeyBoard.fig
%      SIMPLEKEYBOARD, by itself, creates a new SIMPLEKEYBOARD or raises the existing
%      singleton*.
%
%      H = SIMPLEKEYBOARD returns the handle to a new SIMPLEKEYBOARD or the handle to
%      the existing singleton*.
%
%      SIMPLEKEYBOARD('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SIMPLEKEYBOARD.M with the given input arguments.
%
%      SIMPLEKEYBOARD('Property','Value',...) creates a new SIMPLEKEYBOARD or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before simpleKeyBoard_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to simpleKeyBoard_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help simpleKeyBoard

% Last Modified by GUIDE v2.5 23-Nov-2015 08:33:08
% Copyright 2014 - 2016 The MathWorks, Inc.

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @simpleKeyBoard_OpeningFcn, ...
                   'gui_OutputFcn',  @simpleKeyBoard_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before simpleKeyBoard is made visible.
function simpleKeyBoard_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to simpleKeyBoard (see VARARGIN)

% Choose default command line output for simpleKeyBoard
handles.output = hObject;
handles.time = 0.5;
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes simpleKeyBoard wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = simpleKeyBoard_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in A4.
function A4_Callback(hObject, eventdata, handles)
% hObject    handle to A4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.a4t,'Enable','on')
sineSound(440,handles.time);
pause(0.5);


% --- Executes on button press in B4.
function B4_Callback(hObject, eventdata, handles)
% hObject    handle to B4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.b4t,'Enable','on')
sineSound(493.9,handles.time);
pause(0.5);


% --- Executes on button press in C5.
function C5_Callback(hObject, eventdata, handles)
% hObject    handle to C5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.c5t,'Enable','on')
sineSound(523.3,handles.time);
pause(0.5);


% --- Executes on button press in D5.
function D5_Callback(hObject, eventdata, handles)
% hObject    handle to D5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.d5t,'Enable','on')
sineSound(587.3,handles.time);
pause(0.5);


% --- Executes on button press in E5.
function E5_Callback(hObject, eventdata, handles)
% hObject    handle to E5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.e5t,'Enable','on')
sineSound(659.3,handles.time);
pause(0.5);


% --- Executes on button press in F5.
function F5_Callback(hObject, eventdata, handles)
% hObject    handle to F5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.f5t,'Enable','on')
sineSound(698.5,handles.time);
pause(0.5);


% --- Executes on button press in G5.
function G5_Callback(hObject, eventdata, handles)
% hObject    handle to G5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.g5t,'Enable','on')
sineSound(784,handles.time);
pause(0.5);


% --- Executes on button press in A5.
function A5_Callback(hObject, eventdata, handles)
% hObject    handle to A5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.a5t,'Enable','on')
sineSound(880,handles.time);
pause(0.5);


% --- Executes on button press in B5.
function B5_Callback(hObject, eventdata, handles)
% hObject    handle to B5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.b5t,'Enable','on')
sineSound(987.8,handles.time);
pause(0.5);


% --- Executes on button press in Bb4.
function Bb4_Callback(hObject, eventdata, handles)
% hObject    handle to Bb4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.bb4t,'Enable','on')
sineSound(466.2,handles.time);
pause(0.5);


% --- Executes on button press in C5hash.
function C5hash_Callback(hObject, eventdata, handles)
% hObject    handle to C5hash (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.c5ht,'Enable','on')
sineSound(554.4,handles.time);
pause(0.5);


% --- Executes on button press in Eb5.
function Eb5_Callback(hObject, eventdata, handles)
% hObject    handle to Eb5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.eb5t,'Enable','on')
sineSound(622.3,handles.time);
pause(0.5);


% --- Executes on button press in F5hash.
function F5hash_Callback(hObject, eventdata, handles)
% hObject    handle to F5hash (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.f5ht,'Enable','on')
sineSound(740,handles.time);
pause(0.5);


% --- Executes on button press in G5hash.
function G5hash_Callback(hObject, eventdata, handles)
% hObject    handle to G5hash (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.g5ht,'Enable','on')
sineSound(830.6,handles.time);
pause(0.5);


% --- Executes on button press in Bb5.
function Bb5_Callback(hObject, eventdata, handles)
% hObject    handle to Bb5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.bb5t,'Enable','on')
sineSound(932.3,handles.time);
pause(0.5);


% --- Executes on button press in reset.
function reset_Callback(hObject, eventdata, handles)
% hObject    handle to reset (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.f4t,'Enable','off')
set(handles.g4t,'Enable','off')
set(handles.a4t,'Enable','off')
set(handles.b4t,'Enable','off')
set(handles.c5t,'Enable','off')
set(handles.d5t,'Enable','off')
set(handles.e5t,'Enable','off')
set(handles.f5t,'Enable','off')
set(handles.g5t,'Enable','off')
set(handles.a5t,'Enable','off')
set(handles.b5t,'Enable','off')
set(handles.c6t,'Enable','off')
set(handles.d6t,'Enable','off')
set(handles.e6t,'Enable','off')
set(handles.f6t,'Enable','off')
set(handles.g6t,'Enable','off')
set(handles.a6t,'Enable','off')
set(handles.b6t,'Enable','off')
set(handles.f4ht,'Enable','off')
set(handles.g4ht,'Enable','off')
set(handles.bb4t,'Enable','off')
set(handles.c5ht,'Enable','off')
set(handles.eb5t,'Enable','off')
set(handles.f5ht,'Enable','off')
set(handles.g5ht,'Enable','off')
set(handles.bb5t,'Enable','off')
set(handles.c6ht,'Enable','off')
set(handles.eb6t,'Enable','off')
set(handles.f6ht,'Enable','off')
set(handles.g6ht,'Enable','off')
set(handles.bb6t,'Enable','off')

% --- Executes on button press in F4.
function F4_Callback(hObject, eventdata, handles)
% hObject    handle to F4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.f4t,'Enable','on')
sineSound(349.2,handles.time);
pause(0.5);

% --- Executes on button press in G4.
function G4_Callback(hObject, eventdata, handles)
% hObject    handle to G4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.g4t,'Enable','on')
sineSound(392,handles.time);
pause(0.5);

% --- Executes on button press in F4hash.
function F4hash_Callback(hObject, eventdata, handles)
% hObject    handle to F4hash (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.f4ht,'Enable','on')
sineSound(370,handles.time);
pause(0.5);

% --- Executes on button press in G4hash.
function G4hash_Callback(hObject, eventdata, handles)
% hObject    handle to G4hash (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.g4ht,'Enable','on')
sineSound(415.3,handles.time);
pause(0.5);

% --- Executes on button press in C6.
function C6_Callback(hObject, eventdata, handles)
% hObject    handle to C6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.c6t,'Enable','on')
sineSound(1047,handles.time);
pause(0.5);

% --- Executes on button press in D6.
function D6_Callback(hObject, eventdata, handles)
% hObject    handle to D6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.d6t,'Enable','on')
sineSound(1175,handles.time);
pause(0.5);

% --- Executes on button press in E6.
function E6_Callback(hObject, eventdata, handles)
% hObject    handle to E6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.e6t,'Enable','on')
sineSound(1319,handles.time);
pause(0.5);

% --- Executes on button press in F6.
function F6_Callback(hObject, eventdata, handles)
% hObject    handle to F6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.f6t,'Enable','on')
sineSound(1397,handles.time);
pause(0.5);

% --- Executes on button press in G6.
function G6_Callback(hObject, eventdata, handles)
% hObject    handle to G6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.g6t,'Enable','on')
sineSound(1568,handles.time);
pause(0.5);

% --- Executes on button press in A6.
function A6_Callback(hObject, eventdata, handles)
% hObject    handle to A6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.a6t,'Enable','on')
sineSound(1760,handles.time);
pause(0.5);

% --- Executes on button press in B6.
function B6_Callback(hObject, eventdata, handles)
% hObject    handle to B6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.b6t,'Enable','on')
sineSound(1976,handles.time);
pause(0.5);

% --- Executes on button press in C6hash.
function C6hash_Callback(hObject, eventdata, handles)
% hObject    handle to C6hash (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.c6ht,'Enable','on')
sineSound(1109,handles.time);
pause(0.5);

% --- Executes on button press in Eb6.
function Eb6_Callback(hObject, eventdata, handles)
% hObject    handle to Eb6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.eb6t,'Enable','on')
sineSound(1245,handles.time);
pause(0.5);

% --- Executes on button press in F6hash.
function F6hash_Callback(hObject, eventdata, handles)
% hObject    handle to F6hash (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.f6ht,'Enable','on')
sineSound(1480,handles.time);
pause(0.5);

% --- Executes on button press in G6hash.
function G6hash_Callback(hObject, eventdata, handles)
% hObject    handle to G6hash (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.g6ht,'Enable','on')
sineSound(1661,handles.time);
pause(0.5);

% --- Executes on button press in Bb6.
function Bb6_Callback(hObject, eventdata, handles)
% hObject    handle to Bb6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.bb6t,'Enable','on')
sineSound(1865,handles.time);
pause(0.5);
