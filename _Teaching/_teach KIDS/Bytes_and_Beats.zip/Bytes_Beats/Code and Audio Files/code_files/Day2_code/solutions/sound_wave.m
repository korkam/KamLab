% Copyright 2014 - 2016 The MathWorks, Inc.

t = 0: 0.1: 500;
wave = 20*sin(5000*t);
plot(t,wave);
soundsc(wave);
