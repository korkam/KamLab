function playWave(A,F,T)
% Copyright 2014 - 2016 The MathWorks, Inc.
dt =.01;
t0=0;

t = t0:dt:T;
wave = A*sin(F*t);
plot(t,wave);
soundsc(wave);

end

