function addWaves(A1, F1, T1, A2, F2, T2)
% Copyright 2014 - 2016 The MathWorks, Inc.

dt =.01;
t0=0;

t1 = t0:dt:T1;
wave1 = A1*sin(F1*t1);
plot(t1,wave1, 'g');
soundsc(wave1);

hold on;

t2 = t0:dt:T2;
wave2 = A2*sin(F2*t2);
plot(t2,wave2,'r');
soundsc(wave2);

wave3 = wave1 + wave2;


figure;
plot (wave3, 'b')

end
