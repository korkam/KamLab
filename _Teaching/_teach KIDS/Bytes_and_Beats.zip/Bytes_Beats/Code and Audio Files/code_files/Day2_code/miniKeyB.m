function varargout = miniKeyB(varargin)
% MINIKEYB MATLAB code for miniKeyB.fig
%      MINIKEYB, by itself, creates a new MINIKEYB or raises the existing
%      singleton*.
%
%      H = MINIKEYB returns the handle to a new MINIKEYB or the handle to
%      the existing singleton*.
%
%      MINIKEYB('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MINIKEYB.M with the given input arguments.
%
%      MINIKEYB('Property','Value',...) creates a new MINIKEYB or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before miniKeyB_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to miniKeyB_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help miniKeyB

% Last Modified by GUIDE v2.5 22-Dec-2014 13:44:46
% Copyright 2014 - 2016 The MathWorks, Inc.
% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @miniKeyB_OpeningFcn, ...
                   'gui_OutputFcn',  @miniKeyB_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before miniKeyB is made visible.
function miniKeyB_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to miniKeyB (see VARARGIN)

% Choose default command line output for miniKeyB
handles.output = hObject;
set(handles.slider1, 'Value', 0.5);
set(handles.text7, 'String', ['Amp=', num2str(2*get(handles.slider1,'Value'))])
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes miniKeyB wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = miniKeyB_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in ANote.
function ANote_Callback(hObject, eventdata, handles)
% hObject    handle to ANote (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
 Fs=8000;
 Ts=1/Fs;
 t=0:Ts:0.3;
 ANote = 440; %Frequency of note A is 440 Hz
 A = get(handles.slider1, 'Value');
 x = 2*A*sin(2*pi*ANote*t); 
 colors = ['k', 'm', 'c', 'r', 'g', 'b'];
 p = plot(x(1:20), colors(1), 'LineWidth' ,3);
 soundsc(x,1/Ts);
 pause(0.3);
 set(p,'LineWidth', 1)


% --- Executes on button press in BNote.
function BNote_Callback(hObject, eventdata, handles)
% hObject    handle to BNote (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
 Fs=8000;
 Ts=1/Fs;
 t=[0:Ts:0.3];
 BNote = 493.88; %Frequency of note B is 493.88 Hz
 A = get(handles.slider1, 'Value');
 x = 2*A*sin(2*pi*BNote*t); 
 colors = ['k', 'm', 'c', 'r', 'g', 'b'];
 p = plot(x(1:20), colors(2), 'LineWidth' ,3);
 soundsc(x,1/Ts);
 pause(0.3);
 set(p,'LineWidth', 1)


% --- Executes on button press in CNote.
function CNote_Callback(hObject, eventdata, handles)
% hObject    handle to CNote (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
 Fs=8000;
 Ts=1/Fs;
 t=[0:Ts:0.3];
 CNote = 554.37; %Frequency of note C is 554.37 Hz
 A = get(handles.slider1, 'Value');
 x = 2*A*sin(2*pi*CNote*t); 
 colors = ['k', 'm', 'c', 'r', 'g', 'b'];
 p = plot(x(1:20), colors(3), 'LineWidth' ,3);
 soundsc(x,1/Ts);
 pause(0.3);
 set(p,'LineWidth', 1)

 
% --- Executes on button press in DNote.
function DNote_Callback(hObject, eventdata, handles)
% hObject    handle to DNote (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
 Fs=8000;
 Ts=1/Fs;
 t=[0:Ts:0.3];
 DNote = 587.33; %Frequency of note C is 587.33 Hz
 A = get(handles.slider1, 'Value');
 x = 2*A*sin(2*pi*DNote*t); 
 colors = ['k', 'm', 'c', 'r', 'g', 'b'];
 p = plot(x(1:20), colors(4), 'LineWidth' ,3);
 soundsc(x,1/Ts);
 pause(0.3);
 set(p,'LineWidth', 1)

% --- Executes on button press in ENote.
function ENote_Callback(hObject, eventdata, handles)
% hObject    handle to ENote (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
 Fs=8000;
 Ts=1/Fs;
 t=[0:Ts:0.3];
 ENote = 659.26; %Frequency of note E is 659.26 Hz
 A = get(handles.slider1, 'Value');
 x = 2*A*sin(2*pi*ENote*t); 
 colors = ['k', 'm', 'c', 'r', 'g', 'b'];
 p = plot(x(1:20), colors(5), 'LineWidth' ,3);
 soundsc(x,1/Ts);
 pause(0.3);
 set(p,'LineWidth', 1)
 
 
% --- Executes on button press in FNote.
function FNote_Callback(hObject, eventdata, handles)
% hObject    handle to FNote (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
 Fs=8000;
 Ts=1/Fs;
 t=[0:Ts:0.3];
 FNote = 739.9; %Frequency of note F is 739.9 Hz
 A = get(handles.slider1, 'Value');
 x = 2*A*sin(2*pi*FNote*t);
 colors = ['k', 'm', 'c', 'r', 'g', 'b'];
 p = plot(x(1:20), colors(6), 'LineWidth' ,3);
 soundsc(x,1/Ts);
 pause(0.3);
 set(p,'LineWidth', 1)

% --- Executes during object creation, after setting all properties.
function NotesGraph_CreateFcn(hObject, eventdata, handles)
% hObject    handle to NotesGraph (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate NotesGraph
 Fs=8000;
 Ts=1/Fs;
 t=[0:Ts:1];
 F_A = 440; %Frequency of note A is 440 Hz
 F_B = 493.88;
 F_Csharp = 554.37; 
 F_D = 587.33;
 F_E = 659.26;
 F_Fsharp = 739.9;
 A =1;
 notes = [F_A ; F_B; F_Csharp; F_D; F_E; F_Fsharp];
 x = A*sin(2*pi*notes*t); 
 %sig = reshape(x',6*length(t),1);
 %soundsc(sig,1/Ts)
 colors = ['k', 'm', 'c', 'r', 'g', 'b'];
 for i = 1:size(x,1)
     plot(x(i,(1:20)), colors(i));
     grid on;
     hold on;
    % legend('A', 'B', 'C', 'Location','NorthEastOutside');
 end
 %hold off;


% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.text7, 'String', ['Amp=', num2str(2*get(hObject,'Value'))])
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end
