function val = readPin(pin)
%readPin - This command allows you to read data from a Digital or an Analog
%Pin. pin- The input value is either 'D#' for Digital Pins ( where # -> 0 to 13)
%and 'A#' for Analog Pins (where # -> 0 to 5)

% Copyright 2014 - 2015 The MathWorks, Inc.

if  evalin('base', 'exist(''obj'')')
    if evalin('base', 'isa(obj, ''arduino'')')
        obj = evalin('base', 'obj');
        switch pin(1)
            case 'A'
                configureAnalogPin(obj,str2double(pin(2:end)), 'input');
                val = readVoltage(obj, str2double(pin(2:end)));
            case 'D'
                configureDigitalPin(obj,str2double(pin(2:end)), 'input');
                val = readDigitalPin(obj, str2double(pin(2:end)));
        end
    else
        error('***********Use board.Connect to connect to MATLAB*********');
    end
else
    error('***********Use board.Connect to connect to MATLAB*********');
end



