function Connect(port)
% Connect the board to MATLAB
% If a buzzer is connected to Dig Pin 11, then you will hear a connect
% tune.
% You will see a message after the board has been connected or if it has
% already been connected.

% Copyright 2014 - 2015 The MathWorks, Inc.

if nargin == 0
    port = evalin('base', 'port');
end

%Check if the Arduino obj exists already
if  evalin('base', 'sum(sum(strcmp(struct2cell(whos), ''arduino'')))')
    %if evalin('base', 'isa(obj, ''arduino'')')
        try %Check if the board was disconnected by mistake after it was connected earlier
            playTone(evalin('base', 'obj'), 11, 400, 0.2);
        catch err
            evalin('base', 'clear obj');
            error('***********Make sure the Redboard is connected to the PC and try *board.Connect* again*********'); 
        end
        fprintf('\n\n---------------------\n Redboard is already connected to MATLAB!\n---------------------\n\n');
        

else % If the Arduino obj does not exist, then create one to initiate the connection
    try
        obj = arduino(['com', num2str(port)], 'uno');
    catch err
        %rethrow(err)
        error('***********Make sure the Redboard is connected to the PC*********');
    end
    

      assignin('base', 'obj', obj);
end


end