function Disconnect
% Disconnect the board from MATLAB
% If a buzzer is connected to Dig Pin 11, then you will hear a disconnect
% tune.
% You will see a message after the board has been disconnected or if it has
% already been disconnected.

% Copyright 2014 - 2015 The MathWorks, Inc.

if  evalin('base', 'sum(sum(strcmp(struct2cell(whos), ''arduino'')))')
    try
        s = evalin('base', 'struct2cell(whos)');
        y = s(1,ceil(find(strcmp(s, 'arduino'))/9));
    
    catch err
        rethrow(err);
    end
    %         pause(0.2);
    %         playTone(evalin('base', 'obj'), 11, 100, 0.2);
    %         pause(0.2);
    evalin('base', ['clear ', y{1}]);
    fprintf('\n\n---------------------\n Board has been disconnected. \n---------------------\n\n');
else
    fprintf('\n\n---------------------\n Already disconnected!\n---------------------\n\n');
end



