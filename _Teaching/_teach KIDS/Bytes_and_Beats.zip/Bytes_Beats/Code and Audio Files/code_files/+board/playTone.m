function playTone(pin, freq, dur)
%playTone - This command allows you to play Tone on a small speaker or buzzer conneted to 
% a Digital Pin. pin- The input value is 'PMW#' for a Digital PMW Pin ( where # -> 3,5, 6, 9, 10, and 11)
% Copyright 2014 - 2015 The MathWorks, Inc.
if nargin == 2
    duration = 0.2;
else
    duration = dur ;
end

if  evalin('base', 'exist(''obj'')')
    if evalin('base', 'isa(obj, ''arduino'')')
        obj = evalin('base', 'obj');
        configureDigitalPin(obj,str2double(pin(2:end)), 'pwm');
        playTone(obj, str2double(pin(2:end)), freq, duration);
    else
        error('***********Use board.Connect to connect to MATLAB*********');
    end
else
    error('***********Use board.Connect to connect to MATLAB*********');
end

