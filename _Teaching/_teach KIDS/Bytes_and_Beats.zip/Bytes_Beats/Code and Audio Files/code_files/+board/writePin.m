function writePin(pin, val)
%writePin - This command allows you to write data from a Digital Pin- True/False or PWM value.
%pin- The input value is either 'D#' for Digital Pins ( where # -> 0 to 13)
%and 'PMW#' for PMW value to Digital Pins ( where # -> 3,5, 6, 9, 10, and 11)

% Copyright 2014 - 2015 The MathWorks, Inc.

if  evalin('base', 'exist(''obj'')')
    if evalin('base', 'isa(obj, ''arduino'')')
        obj = evalin('base', 'obj');
        switch pin(1)
            case 'P'
                configureDigitalPin(obj,str2double(pin(4:end)), 'pwm');
                writeDigitalPin(obj, str2double(pin(4:end)), val);
            case 'D'
                configureDigitalPin(obj,str2double(pin(2:end)), 'output');
                writeDigitalPin(obj, str2double(pin(2:end)), val);
        end
    else
        error('***********Use board.Connect to connect to MATLAB*********');
    end
else
   error('***********Use board.Connect to connect to MATLAB*********');
end


